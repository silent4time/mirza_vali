<?php
/**
 * Safe injector for eylan into panels.php — only adds branches, does not alter other types.
 * Usage: php /var/www/mirza_vali/apply_eylan_panels.php
 */
$panels = __DIR__ . '/panels.php';
if (!is_file($panels)) {
    fwrite(STDERR, "ERROR: panels.php not found\n");
    exit(1);
}
$src = file_get_contents($panels);

if (strpos($src, 'Eylan.php') === false) {
    $line = "\nif (is_file(__DIR__ . '/Eylan.php')) { require_once __DIR__ . '/Eylan.php'; }\n";
    if (preg_match('/require(_once)?\s+[\'"][^\'"]*function\.php[\'"]\s*;/', $src, $m, PREG_OFFSET_CAPTURE)) {
        $end = $m[0][1] + strlen($m[0][0]);
        $src = substr($src, 0, $end) . $line . substr($src, $end);
    } else {
        $src = preg_replace('/^<\?php/', "<?php\n" . trim($line), $src, 1);
    }
    echo "OK require\n";
} else {
    echo "SKIP require\n";
}

$createEylan = <<<'PHP'
        } elseif ($Get_Data_Panel['type'] == "eylan") {
            if (!function_exists('eylan_create_user')) {
                return array('status' => 'Unsuccessful', 'msg' => 'Eylan.php not loaded');
            }
            $volume_gb = 0;
            if (isset($data_limit) && $data_limit > 0) {
                $volume_gb = floatval($data_limit) / (1024 * 1024 * 1024);
            }
            if ($volume_gb <= 0 && isset($Get_Data_Product['Volume_constraint'])) {
                $volume_gb = floatval($Get_Data_Product['Volume_constraint']);
            }
            $expire_ts = isset($expire) ? intval($expire) : 0;
            $days = 0;
            if ($expire_ts > time()) {
                $days = intval(ceil(($expire_ts - time()) / 86400));
            } elseif (isset($Get_Data_Product['Service_time'])) {
                $days = intval($Get_Data_Product['Service_time']);
                if ($days > 0) {
                    $expire_ts = time() + ($days * 86400);
                }
            }
            $protocol = isset($Get_Data_Panel['inboundid']) ? $Get_Data_Panel['inboundid'] : 'multi';
            $extra = array(
                'days' => $days,
                'note' => isset($note) ? $note : ('Created by bot ' . date('Y-m-d H:i')),
                'protocol' => $protocol,
            );
            $result = eylan_create_user($Get_Data_Panel['name_panel'], $usernameC, $volume_gb, $expire_ts, $extra);
            $ok = function_exists('eylan_http_ok') ? eylan_http_ok($result) : (isset($result['http_code']) && $result['http_code'] >= 200 && $result['http_code'] < 300 && empty($result['error']));
            if ($ok) {
                $delivery = eylan_build_delivery($Get_Data_Panel['name_panel'], $usernameC, $protocol);
                $sub_url = isset($delivery['subscription_url']) ? $delivery['subscription_url'] : '';
                if ($invoice != false && !empty($domainhosts)) {
                    $sub_url = "https://$domainhosts/sub/" . $invoice['id_invoice'];
                }
                $Output['status'] = 'successful';
                $Output['username'] = $usernameC;
                $Output['subscription_url'] = $sub_url;
                $Output['configs'] = !empty($delivery['configs']) ? $delivery['configs'] : array();
                if (!empty($delivery['text'])) {
                    $Output['configs'][] = $delivery['text'];
                }
            } else {
                $Output['status'] = 'Unsuccessful';
                $Output['msg'] = isset($result['message']) ? $result['message'] : (isset($result['error']) ? $result['error'] : 'Eylan create failed');
            }
PHP;

$dataEylan = <<<'PHP'
        } elseif ($Get_Data_Panel['type'] == "eylan") {
            if (!function_exists('eylan_to_datauser_output')) {
                $Output = array('status' => 'Unsuccessful', 'msg' => 'Eylan.php not loaded');
            } else {
                $inv = isset($invoice) ? $invoice : false;
                $Output = eylan_to_datauser_output($Get_Data_Panel['name_panel'], $username, $inv);
            }
PHP;

// Unique anchors: final else of createUser before return + DataUser function
$createAnchor = <<<'PHP'
        } else {
            $Output['status'] = 'Unsuccessful';
            $Output['msg'] = 'Panel Not Found';
        }
        return $Output;
    }
    function DataUser($name_panel, $username)
PHP;

$createReplacement = $createEylan . "\n" . $createAnchor;

$dataAnchor = <<<'PHP'
        } else {
            $Output = array(
                'status' => 'Unsuccessful',
                'msg' => 'Panel Not Found'
            );
        }
        return $Output;
    }
    function Revoke_sub($name_panel, $username)
PHP;

$dataReplacement = $dataEylan . "\n" . $dataAnchor;

if (strpos($src, 'eylan_create_user') === false) {
    if (strpos($src, $createAnchor) !== false) {
        $src = str_replace($createAnchor, $createReplacement, $src);
        echo "OK createUser\n";
    } else {
        echo "FAIL createUser: anchor not found (panels.php structure differs)\n";
        echo "Manual: insert eylan branch before final Panel Not Found in createUser\n";
    }
} else {
    echo "SKIP createUser\n";
}

if (strpos($src, 'eylan_to_datauser_output') === false) {
    if (strpos($src, $dataAnchor) !== false) {
        $src = str_replace($dataAnchor, $dataReplacement, $src);
        echo "OK DataUser\n";
    } else {
        // Revoke_sub might not exist with same name
        $alt = str_replace('function Revoke_sub($name_panel, $username)', 'function RemoveUser($name_panel, $username)', $dataAnchor);
        $altRep = str_replace('function Revoke_sub($name_panel, $username)', 'function RemoveUser($name_panel, $username)', $dataReplacement);
        if (strpos($src, $alt) !== false) {
            $src = str_replace($alt, $altRep, $src);
            echo "OK DataUser (RemoveUser anchor)\n";
        } else {
            echo "FAIL DataUser: anchor not found\n";
        }
    }
} else {
    echo "SKIP DataUser\n";
}

$bak = $panels . '.bak_eylan_' . date('YmdHis');
copy($panels, $bak);
file_put_contents($panels, $src);
echo "Backup: $bak\n";
passthru('php -l ' . escapeshellarg($panels), $code);
exit((int) $code);
