<?php
/**
 * mirza_vali — database backup cron
 * Safer mysqldump + fallback PDO dump + real error text to report channel
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../function.php';
$textbotlang = languagechange();
require_once __DIR__ . '/../botapi.php';

$reportbackup = 0;
try {
    $row = select("topicid", "idreport", "report", "backupfile", "select");
    if (is_array($row) && isset($row['idreport'])) {
        $reportbackup = intval($row['idreport']);
    }
} catch (Throwable $e) {
    $reportbackup = 0;
}

$setting = select("setting", "*");
$channel = is_array($setting) ? ($setting['Channel_Report'] ?? '') : '';

function mv_backup_notify($text, $channel, $thread)
{
    if ($channel === '' || $channel === null) {
        error_log('backupbot: ' . $text);
        return;
    }
    $payload = [
        'chat_id' => $channel,
        'text' => $text,
    ];
    if ($thread > 0) {
        $payload['message_thread_id'] = $thread;
    }
    telegram('sendmessage', $payload);
}

function mv_pdo_dump($pdo, $dbname, $outfile)
{
    $fh = fopen($outfile, 'w');
    if (!$fh) {
        return 'Cannot write dump file: ' . $outfile;
    }
    fwrite($fh, "-- mirza_vali PDO backup\n-- DB: {$dbname}\n-- Date: " . date('c') . "\n\nSET FOREIGN_KEY_CHECKS=0;\n\n");
    $tables = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $table) {
        $create = $pdo->query("SHOW CREATE TABLE `{$table}`")->fetch(PDO::FETCH_NUM);
        fwrite($fh, "DROP TABLE IF EXISTS `{$table}`;\n" . $create[1] . ";\n\n");
        $rows = $pdo->query("SELECT * FROM `{$table}`", PDO::FETCH_ASSOC);
        foreach ($rows as $row) {
            $cols = array_map(function ($c) {
                return '`' . str_replace('`', '``', $c) . '`';
            }, array_keys($row));
            $vals = array_map(function ($v) use ($pdo) {
                if ($v === null) {
                    return 'NULL';
                }
                return $pdo->quote($v);
            }, array_values($row));
            fwrite($fh, 'INSERT INTO `' . $table . '` (' . implode(',', $cols) . ') VALUES (' . implode(',', $vals) . ");\n");
        }
        fwrite($fh, "\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS=1;\n");
    fclose($fh);
    return null;
}

$destination = __DIR__;
$backup_file_name = $destination . '/backup_' . date('Y-m-d_His') . '.sql';
$dbhost = empty($dbhost) ? 'localhost' : $dbhost;

// Prefer defaults-extra-file so password is not visible in process list / shell breakage
$cnf = $destination . '/.my.cnf.bak.' . getmypid();
$cnfBody = "[client]\nhost={$dbhost}\nuser={$usernamedb}\npassword=\"{$passworddb}\"\n";
@file_put_contents($cnf, $cnfBody);
@chmod($cnf, 0600);

$mysqldump = trim((string) shell_exec('command -v mysqldump 2>/dev/null'));
$ok = false;
$errDetail = '';

if ($mysqldump !== '') {
    $cmd = escapeshellcmd($mysqldump)
        . ' --defaults-extra-file=' . escapeshellarg($cnf)
        . ' --no-tablespaces --single-transaction --routines --triggers '
        . escapeshellarg($dbname)
        . ' > ' . escapeshellarg($backup_file_name)
        . ' 2> ' . escapeshellarg($backup_file_name . '.err');
    $return_var = 0;
    exec($cmd, $output, $return_var);
    @unlink($cnf);
    if ($return_var === 0 && is_file($backup_file_name) && filesize($backup_file_name) > 50) {
        $ok = true;
    } else {
        $errDetail = is_file($backup_file_name . '.err') ? trim(file_get_contents($backup_file_name . '.err')) : "mysqldump exit={$return_var}";
        @unlink($backup_file_name . '.err');
        // retry without single-transaction
        $cmd2 = escapeshellcmd($mysqldump)
            . ' -h ' . escapeshellarg($dbhost)
            . ' -u ' . escapeshellarg($usernamedb)
            . ' -p' . escapeshellarg($passworddb)
            . ' --no-tablespaces '
            . escapeshellarg($dbname)
            . ' > ' . escapeshellarg($backup_file_name)
            . ' 2> ' . escapeshellarg($backup_file_name . '.err');
        exec($cmd2, $output, $return_var);
        if ($return_var === 0 && is_file($backup_file_name) && filesize($backup_file_name) > 50) {
            $ok = true;
            $errDetail = '';
        } else {
            $errDetail = is_file($backup_file_name . '.err') ? trim(file_get_contents($backup_file_name . '.err')) : $errDetail;
            @unlink($backup_file_name . '.err');
        }
    }
} else {
    $errDetail = 'mysqldump not found in PATH';
}
@unlink($cnf);

if (!$ok) {
    // Fallback: pure PHP dump
    $pdoErr = mv_pdo_dump($pdo, $dbname, $backup_file_name);
    if ($pdoErr === null && is_file($backup_file_name) && filesize($backup_file_name) > 50) {
        $ok = true;
        $errDetail = '';
    } else {
        $errDetail = trim($errDetail . ' | PDO: ' . ($pdoErr ?? 'empty file'));
    }
}

if (!$ok) {
    $msg = $textbotlang['keyboard']['backupError'] ?? '❌ خطا در بکاپ گیری';
    $msg .= "\n\n<code>" . htmlspecialchars(mb_substr($errDetail, 0, 500)) . '</code>';
    mv_backup_notify($msg, $channel, $reportbackup);
    error_log('backupbot failed: ' . $errDetail);
    @unlink($backup_file_name);
    exit(1);
}

$caption = $textbotlang['Admin']['report']['backupCaption'] ?? ('Backup ' . date('Y-m-d H:i'));
$docPayload = [
    'chat_id' => $channel,
    'document' => new CURLFile($backup_file_name),
    'caption' => $caption,
];
if ($reportbackup > 0) {
    $docPayload['message_thread_id'] = $reportbackup;
}
$send = telegram('sendDocument', $docPayload);
if (empty($send['ok'])) {
    // try without thread
    unset($docPayload['message_thread_id']);
    $send = telegram('sendDocument', $docPayload);
}
@unlink($backup_file_name);

if (empty($send['ok'])) {
    mv_backup_notify(($textbotlang['keyboard']['backupError'] ?? '❌ خطا در بکاپ گیری') . "\nSendDocument failed: " . json_encode($send), $channel, $reportbackup);
    exit(1);
}
exit(0);
