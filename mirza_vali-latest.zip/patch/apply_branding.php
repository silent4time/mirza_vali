<?php
$candidates = [
    getcwd() . '/lang/fa.php',
    __DIR__ . '/lang/fa.php',
    dirname(__DIR__) . '/lang/fa.php',
];
$fa = null;
foreach ($candidates as $c) {
    if (is_file($c)) { $fa = $c; break; }
}
if (!$fa) {
    fwrite(STDERR, "lang/fa.php not found\n");
    exit(1);
}
$t = file_get_contents($fa);
$orig = $t;

// --- aboutBot ---
$newAbout = "'aboutBot' => '💎 | Version Bot: %s
📌 | Version Mini App: 0.1.1

🔹 | این ربات کاملاً رایگان است و توسط silent4time (https://github.com/silent4time) توسعه داده شده است

🔹 | هرگونه فروش یا دریافت وجه بابت این ربات تخلف محسوب می‌شود.

🔹 | در صورت مشاهدهٔ فروش یا دریافت وجه، لطفاً وجه خود را پیگیری کرده و بازپس‌گیری نمایید.

🐞 | اگر در عملکرد ربات با باگ یا مشکلی مواجه شدید، از طریق دکمهٔ **📬 گزارش ربات** در پنل ادمین با ما در ارتباط باشید.',
";
$t2 = preg_replace("/'aboutBot'\\s*=>\\s*'.*?',\\s*\\n/s", $newAbout . "\n", $t, 1);
if ($t2 !== null && $t2 !== $t) {
    $t = $t2;
    echo "OK aboutBot\n";
} else {
    echo "WARN aboutBot not replaced\n";
}

// --- botReportIntro ---
$newReport = "'botReportIntro' => '💬 | گزارش ربات

🔹 | اگر در عملکرد ربات با باگ یا مشکلی روبه‌رو شدید، لطفاً مورد را برای بررسی به ما اطلاع دهید.
➖➖➖➖➖➖➖➖➖➖➖
🔹 | در صورتی که با باگ جدی یا رفتار غیرعادی مواجه شدید، سریع‌تر گزارش دهید تا رفع شود.
➖➖➖➖➖➖➖➖➖➖➖
🔹 | اگر پیشنهادی برای افزودن قابلیت جدید دارید یا ایده‌ای برای بهبود عملکرد ربات در نظر دارید، خوشحال می‌شویم بشنویم.
➖➖➖➖➖➖➖➖➖➖➖
🔹 | همچنین اگر نیاز به راهنمایی یا کمک دارید، می‌توانید از طریق دایرکت با تیم پشتیبانی در ارتباط باشید.

📩 | برای ارسال گزارش، پیشنهاد یا درخواست راهنمایی، ایمیل بگذارید:
<a href=\"mailto:silentping.vpn@gmail.com\">silent4time</a> (silentping.vpn@gmail.com)',
";
$t3 = preg_replace("/'botReportIntro'\\s*=>\\s*'.*?',\\s*\\n/s", $newReport . "\n", $t, 1);
if ($t3 !== null && $t3 !== $t) {
    $t = $t3;
    echo "OK botReportIntro\n";
} else {
    // fallback footer only
    if (strpos($t, 'mirzapanelgroup') !== false) {
        $t = preg_replace('#📩 \| برای ارسال گزارش.*?Mirza Group</a>#s',
            "📩 | برای ارسال گزارش، پیشنهاد یا درخواست راهنمایی، ایمیل بگذارید:\n<a href=\"mailto:silentping.vpn@gmail.com\">silent4time</a> (silentping.vpn@gmail.com)",
            $t);
        echo "FALLBACK botReportIntro footer\n";
    } else {
        echo "WARN botReportIntro not replaced\n";
    }
}

if ($t === $orig) {
    echo "No change\n";
    exit(0);
}
file_put_contents($fa, $t);
echo "OK saved: $fa\n";
exit(0);
