# Eylan panel — setup (v1.8.11)

## 1) Copy files to bot root
```bash
cp Eylan.php apply_eylan_panels.php /var/www/mirza_vali/
```

## 2) Inject into panels.php (safe, one-time)
```bash
cd /var/www/mirza_vali
php apply_eylan_panels.php
php -l panels.php
```
Only adds `eylan` branches; other panel types are untouched. Re-run is safe (SKIP).

## 3) Register panel in bot admin
- Type: **eylan**
- URL: `https://panel.silentping.ir:8050` (your panel base, no trailing path)
- Password field: **API Key** from Eylan
- **inboundid** = protocol mode:
  - `openvpn` — only OpenVPN
  - `l2tp` — only L2TP/IPsec
  - `cisco` — only Cisco AnyConnect
  - `wireguard` — only WireGuard (wg1)
  - `multi` — all four (default if empty)

## 4) Nodes
Eylan needs at least one Node. Without nodes, configs may be empty.

## 5) What user receives
| Mode | Content |
|------|---------|
| openvpn | sub URL + OVPN links |
| l2tp | server + username + password |
| cisco | server + username + password |
| wireguard | WG files / config |
| multi | all of the above |

## Rollback
```bash
cp panels.php.bak_eylan_* panels.php   # use the backup file name printed by the script
```
