# اعمال پشتیبانی Eylan روی panels.php سرور

روی سرور که panels.php کامل دارید:

1. کپی Eylan.php کنار panels.php
2. اضافه کردن require:
   require_once __DIR__ . '/Eylan.php';

3. در تابع createUser بعد از بلاک rebecca و قبل از } else { این کد را اضافه کنید:

        } elseif ($Get_Data_Panel['type'] == "eylan") {
            $volume_gb = isset($data_limit) ? floatval($data_limit) / (1024 * 1024 * 1024) : 0;
            if ($volume_gb <= 0 && isset($Get_Data_Product['Volume_constraint'])) {
                $volume_gb = floatval($Get_Data_Product['Volume_constraint']);
            }
            $expire_ts = isset($expire) ? intval($expire) : 0;
            $days = 0;
            if ($expire_ts > time()) {
                $days = intval(($expire_ts - time()) / 86400);
            } elseif (isset($Get_Data_Product['Service_time'])) {
                $days = intval($Get_Data_Product['Service_time']);
                $expire_ts = time() + ($days * 86400);
            }
            $extra = ['days' => $days, 'note' => $note ?? ('Created by bot ' . date('Y-m-d H:i'))];
            $result = eylan_create_user($Get_Data_Panel['name_panel'], $usernameC, $volume_gb, $expire_ts, $extra);
            if ((isset($result['success']) && $result['success']) || (isset($result['http_code']) && $result['http_code'] >= 200 && $result['http_code'] < 300 && empty($result['error']))) {
                $sub = eylan_get_sub($Get_Data_Panel['name_panel'], $usernameC);
                $sub_url = '';
                if (!empty($sub['sub_url'])) $sub_url = $sub['sub_url'];
                elseif (!empty($sub['url'])) $sub_url = $sub['url'];
                elseif (!empty($sub['subscription_url'])) $sub_url = $sub['subscription_url'];
                if ($invoice != false && !empty($domainhosts)) {
                    $sub_url = "https://$domainhosts/sub/" . $invoice['id_invoice'];
                }
                $Output['status'] = 'successful';
                $Output['username'] = $usernameC;
                $Output['subscription_url'] = $sub_url;
                $Output['configs'] = [];
            } else {
                $Output['status'] = 'Unsuccessful';
                $Output['msg'] = $result['message'] ?? $result['error'] ?? json_encode($result);
            }

نکته مهم: فیلد لینک ساب در API ایلان `sub_url` است.
