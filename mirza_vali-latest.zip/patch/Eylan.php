<?php
/**
 * EylanPanel API Integration for mirza_vali
 * Version: 1.8.11
 * Auth: X-API-KEY header (stored in marzban_panel.password_panel)
 * Docs: https://eylandoo.github.io/
 *
 * Protocol mode (panel field inboundid or $extra['protocol']):
 *   openvpn | l2tp | cisco | wireguard | multi
 * Default: multi
 */

if (!function_exists('eylan_request')) {

function eylan_request($method, $endpoint, $panel, $body = null)
{
    if (!is_array($panel) || empty($panel['url_panel'])) {
        return ['success' => false, 'error' => 'Invalid panel', 'http_code' => 0];
    }
    $base = rtrim($panel['url_panel'], '/');
    $url = $base . $endpoint;
    $headers = [
        'Accept: application/json',
        'Content-Type: application/json',
        'X-API-KEY: ' . ($panel['password_panel'] ?? ''),
    ];
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
    ]);
    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body, JSON_UNESCAPED_UNICODE));
    }
    $response = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($error) {
        return ['success' => false, 'error' => $error, 'http_code' => $httpCode];
    }
    $decoded = json_decode((string) $response, true);
    if (!is_array($decoded)) {
        return ['success' => false, 'error' => 'Invalid JSON', 'raw' => substr((string) $response, 0, 500), 'http_code' => $httpCode];
    }
    $decoded['http_code'] = $httpCode;
    return $decoded;
}

function eylan_get_panel($namepanel)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    return (is_array($panel) && !empty($panel['name_panel'])) ? $panel : null;
}

/**
 * Normalize protocol mode string.
 */
function eylan_normalize_protocol($raw)
{
    $p = strtolower(trim((string) $raw));
    $map = [
        'openvpn' => 'openvpn', 'ovpn' => 'openvpn', 'vpn' => 'openvpn',
        'l2tp' => 'l2tp', 'ipsec' => 'l2tp',
        'cisco' => 'cisco', 'anyconnect' => 'cisco', 'ocserv' => 'cisco',
        'wireguard' => 'wireguard', 'wg' => 'wireguard', 'wg1' => 'wireguard',
        'multi' => 'multi', 'all' => 'multi', 'مولتی' => 'multi',
    ];
    return $map[$p] ?? 'multi';
}

/**
 * Resolve protocol from extra, then panel inboundid, then multi.
 */
function eylan_resolve_protocol($panel, $extra = [])
{
    if (!empty($extra['protocol'])) {
        return eylan_normalize_protocol($extra['protocol']);
    }
    if (is_array($panel) && !empty($panel['inboundid'])) {
        return eylan_normalize_protocol($panel['inboundid']);
    }
    return 'multi';
}

/**
 * Build enable_* flags for create/update body.
 */
function eylan_protocol_flags($protocol)
{
    $protocol = eylan_normalize_protocol($protocol);
    $flags = [
        'enable_openvpn' => false,
        'enable_l2tp' => false,
        'enable_cisco' => false,
        'enable_wg1' => false,
    ];
    if ($protocol === 'multi') {
        $flags = [
            'enable_openvpn' => true,
            'enable_l2tp' => true,
            'enable_cisco' => true,
            'enable_wg1' => true,
        ];
    } elseif ($protocol === 'openvpn') {
        $flags['enable_openvpn'] = true;
    } elseif ($protocol === 'l2tp') {
        $flags['enable_l2tp'] = true;
    } elseif ($protocol === 'cisco') {
        $flags['enable_cisco'] = true;
    } elseif ($protocol === 'wireguard') {
        $flags['enable_wg1'] = true;
    }
    return $flags;
}

function eylan_http_ok($result)
{
    if (!is_array($result)) {
        return false;
    }
    $code = (int) ($result['http_code'] ?? 0);
    if (!empty($result['error']) && $code >= 400) {
        return false;
    }
    if (isset($result['success']) && $result['success'] === false) {
        return false;
    }
    if ($code > 0 && ($code < 200 || $code >= 300)) {
        return false;
    }
    return true;
}

/**
 * Create user on EylanPanel.
 *
 * @param string $namepanel
 * @param string $username
 * @param float  $data_limit_gb
 * @param int    $expire_timestamp unix ts (0 = unlimited-ish / use days from extra)
 * @param array  $extra protocol, days, note, max_clients, nodes, wg_instances, l2tp_password, cisco_password
 */
function eylan_create_user($namepanel, $username, $data_limit_gb, $expire_timestamp, $extra = [])
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    $protocol = eylan_resolve_protocol($panel, $extra);
    $flags = eylan_protocol_flags($protocol);

    $days = isset($extra['days']) ? (int) $extra['days'] : 0;
    if ($days <= 0 && $expire_timestamp > time()) {
        $days = (int) max(1, ceil(($expire_timestamp - time()) / 86400));
    }

    $body = array_merge([
        'username' => $username,
        'data_limit' => round(floatval($data_limit_gb), 2),
        'data_limit_unit' => 'GB',
        'max_clients' => isset($extra['max_clients']) ? (int) $extra['max_clients'] : 1,
        'notes' => $extra['note'] ?? ($extra['notes'] ?? ('bot ' . date('Y-m-d H:i'))),
        'activation_type' => 'fixed_date',
    ], $flags);

    if ($days > 0) {
        $body['expiry_days'] = $days;
    } elseif ($expire_timestamp > 0) {
        $body['expiry_date_str'] = date('Y-m-d', $expire_timestamp);
    }

    if (!empty($extra['nodes']) && is_array($extra['nodes'])) {
        $body['nodes'] = $extra['nodes'];
    }
    if ($flags['enable_l2tp'] && !empty($extra['l2tp_password'])) {
        $body['l2tp_password'] = $extra['l2tp_password'];
    }
    if ($flags['enable_cisco'] && !empty($extra['cisco_password'])) {
        $body['cisco_password'] = $extra['cisco_password'];
    }
    if ($flags['enable_wg1'] && !empty($extra['wg_instances']) && is_array($extra['wg_instances'])) {
        $body['wg_instances'] = $extra['wg_instances'];
    }

    $result = eylan_request('POST', '/api/v1/users', $panel, $body);
    $result['_protocol'] = $protocol;
    $result['_request_body'] = $body;
    return $result;
}

function eylan_get_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username), $panel);
}

function eylan_get_sub($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/sub', $panel);
}

function eylan_get_ovpn_links($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/all_ovpn_links', $panel);
}

function eylan_get_wg_files($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
}

function eylan_toggle_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/toggle', $panel);
}

function eylan_reset_traffic($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/reset_traffic', $panel);
}

function eylan_revoke($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/revoke', $panel);
}

function eylan_delete_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    $result = eylan_request('DELETE', '/api/v1/users/' . rawurlencode($username), $panel);
    if (eylan_http_ok($result)) {
        return $result;
    }
    return eylan_toggle_user($namepanel, $username);
}

function eylan_status($namepanel)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/status', $panel);
}

/**
 * Collect delivery payload for bot message: sub url + config links + credential text.
 */
function eylan_build_delivery($namepanel, $username, $protocol = null)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return [
            'subscription_url' => '',
            'configs' => [],
            'text' => '',
            'user' => null,
        ];
    }
    if ($protocol === null) {
        $protocol = eylan_resolve_protocol($panel, []);
    } else {
        $protocol = eylan_normalize_protocol($protocol);
    }

    $user = eylan_get_user($namepanel, $username);
    $sub = eylan_get_sub($namepanel, $username);

    $sub_url = '';
    foreach (['sub_url', 'url', 'subscription_url'] as $k) {
        if (!empty($sub[$k]) && is_string($sub[$k])) {
            $sub_url = $sub[$k];
            break;
        }
    }
    if ($sub_url === '' && !empty($user['sub_url'])) {
        $sub_url = $user['sub_url'];
    }
    // relative -> absolute
    if ($sub_url !== '' && !preg_match('#^https?://#i', $sub_url)) {
        $sub_url = rtrim($panel['url_panel'], '/') . '/' . ltrim($sub_url, '/');
    }

    $configs = [];
    $lines = [];
    $lines[] = "🔐 سرویس: <b>{$username}</b>";
    $lines[] = "پروتکل: <b>{$protocol}</b>";

    $need_ovpn = in_array($protocol, ['openvpn', 'multi'], true);
    $need_l2tp = in_array($protocol, ['l2tp', 'multi'], true);
    $need_cisco = in_array($protocol, ['cisco', 'multi'], true);
    $need_wg = in_array($protocol, ['wireguard', 'multi'], true);

    if ($need_ovpn) {
        if ($sub_url !== '') {
            $lines[] = "\n📡 <b>OpenVPN / صفحه ساب</b>\n<code>{$sub_url}</code>";
            $configs[] = $sub_url;
        }
        $ovpn = eylan_get_ovpn_links($namepanel, $username);
        if (is_array($ovpn)) {
            $links = $ovpn['links'] ?? $ovpn['files'] ?? $ovpn['data'] ?? null;
            if (is_array($links)) {
                foreach ($links as $item) {
                    if (is_string($item) && $item !== '') {
                        $configs[] = $item;
                        $lines[] = "• OVPN: <code>{$item}</code>";
                    } elseif (is_array($item)) {
                        $u = $item['url'] ?? $item['link'] ?? $item['download_url'] ?? '';
                        $n = $item['name'] ?? $item['server'] ?? 'ovpn';
                        if ($u !== '') {
                            $configs[] = $u;
                            $lines[] = "• {$n}: <code>{$u}</code>";
                        }
                    }
                }
            }
        }
    }

    if ($need_l2tp) {
        $l2tp_pass = $user['l2tp_password'] ?? $user['l2tp_pass'] ?? '';
        $server = $user['l2tp_server'] ?? $user['server'] ?? parse_url($panel['url_panel'], PHP_URL_HOST);
        $lines[] = "\n🛡️ <b>L2TP / IPsec</b>";
        $lines[] = "سرور: <code>{$server}</code>";
        $lines[] = "یوزرنیم: <code>{$username}</code>";
        if ($l2tp_pass !== '') {
            $lines[] = "رمز: <code>{$l2tp_pass}</code>";
        } else {
            $lines[] = "رمز: از پنل / پروفایل کاربر بخوانید";
        }
        $lines[] = "Secret/PSK: از تنظیمات پنل (IPsec PSK)";
    }

    if ($need_cisco) {
        $cisco_pass = $user['cisco_password'] ?? $user['cisco_pass'] ?? '';
        $server = $user['cisco_server'] ?? parse_url($panel['url_panel'], PHP_URL_HOST);
        $lines[] = "\n🌐 <b>Cisco AnyConnect</b>";
        $lines[] = "سرور: <code>{$server}</code>";
        $lines[] = "یوزرنیم: <code>{$username}</code>";
        if ($cisco_pass !== '') {
            $lines[] = "رمز: <code>{$cisco_pass}</code>";
        } else {
            $lines[] = "رمز: از پنل / پروفایل کاربر بخوانید";
        }
    }

    if ($need_wg) {
        $wg = eylan_get_wg_files($namepanel, $username);
        $lines[] = "\n🧩 <b>WireGuard</b>";
        if (is_array($wg)) {
            $files = $wg['files'] ?? $wg['configs'] ?? $wg['data'] ?? null;
            if (is_array($files)) {
                foreach ($files as $item) {
                    if (is_string($item) && $item !== '') {
                        $configs[] = $item;
                        $lines[] = "• WG: <code>{$item}</code>";
                    } elseif (is_array($item)) {
                        $u = $item['url'] ?? $item['link'] ?? $item['download_url'] ?? $item['config'] ?? '';
                        $n = $item['name'] ?? $item['instance'] ?? 'wg';
                        if ($u !== '') {
                            if (str_starts_with($u, 'http')) {
                                $configs[] = $u;
                            }
                            $lines[] = "• {$n}: <code>" . mb_substr($u, 0, 200) . "</code>";
                        }
                    }
                }
            } elseif (!empty($wg['config']) && is_string($wg['config'])) {
                $lines[] = "<code>" . htmlspecialchars(mb_substr($wg['config'], 0, 500)) . "</code>";
            } else {
                $lines[] = "فایل WG از پنل قابل دریافت است.";
            }
        } else {
            $lines[] = "فایل WG از پنل قابل دریافت است.";
        }
        if (!empty($user['wg1_ip'])) {
            $lines[] = "IP: <code>{$user['wg1_ip']}</code>";
        }
    }

    return [
        'subscription_url' => $sub_url,
        'configs' => array_values(array_unique(array_filter($configs))),
        'text' => implode("\n", $lines),
        'user' => $user,
        'protocol' => $protocol,
    ];
}

/**
 * Map Eylan user to mirza DataUser-style array.
 */
function eylan_to_datauser_output($namepanel, $username, $invoice = false)
{
    global $domainhosts;
    $panel = eylan_get_panel($namepanel);
    $user = eylan_get_user($namepanel, $username);
    if (!eylan_http_ok($user) && empty($user['username'])) {
        return ['status' => 'Unsuccessful', 'msg' => $user['message'] ?? $user['error'] ?? 'User not found'];
    }

    $delivery = eylan_build_delivery($namepanel, $username);
    $sub_url = $delivery['subscription_url'];
    if ($invoice != false && !empty($domainhosts) && is_array($invoice) && !empty($invoice['id_invoice'])) {
        $sub_url = "https://{$domainhosts}/sub/" . $invoice['id_invoice'];
    }

    $data_limit_gb = floatval($user['data_limit'] ?? 0);
    $data_limit_bytes = (int) round($data_limit_gb * 1024 * 1024 * 1024);
    $used = floatval($user['download_bytes'] ?? $user['used_traffic'] ?? $user['traffic_bytes'] ?? 0);
    // if used looks like GB already, leave; if bytes keep
    if ($used > 0 && $used < 10000 && $data_limit_gb > 0) {
        $used = $used * 1024 * 1024 * 1024;
    }

    $expire = 0;
    if (!empty($user['expire'])) {
        $expire = is_numeric($user['expire']) ? (int) $user['expire'] : strtotime($user['expire']);
    } elseif (!empty($user['expiry_date'])) {
        $expire = strtotime($user['expiry_date']);
    }

    $status = 'active';
    if (isset($user['is_active']) && !$user['is_active']) {
        $status = 'disabled';
    }
    if (!empty($user['is_disabled'])) {
        $status = 'disabled';
    }
    if ($expire > 0 && $expire < time()) {
        $status = 'expired';
    }

    return [
        'status' => $status,
        'username' => $user['username'] ?? $username,
        'data_limit' => $data_limit_bytes,
        'expire' => $expire ?: null,
        'online_at' => $user['online_at'] ?? null,
        'used_traffic' => (int) $used,
        'links' => $delivery['configs'],
        'subscription_url' => $sub_url,
        'sub_updated_at' => null,
        'sub_last_user_agent' => null,
        'uuid' => null,
        'data_limit_reset' => null,
        'eylan_text' => $delivery['text'],
        'eylan_protocol' => $delivery['protocol'],
    ];
}

} // end function_exists guard
