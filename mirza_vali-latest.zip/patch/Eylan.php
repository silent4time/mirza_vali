<?php
/**
 * EylanPanel API Integration for mirza_vali
 * Version: 1.8.9
 * Auth: X-API-KEY header
 * Base endpoints from https://eylandoo.github.io/
 */

if (!function_exists('eylan_request')) {

function eylan_request($method, $endpoint, $panel, $body = null)
{
    $base = rtrim($panel['url_panel'], '/');
    $url = $base . $endpoint;

    $headers = [
        'Accept: application/json',
        'Content-Type: application/json',
        'X-API-KEY: ' . $panel['password_panel']
    ];

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 25,
        CURLOPT_CONNECTTIMEOUT => 10,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
    ]);

    if ($body !== null) {
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($body));
    }

    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);

    if ($error) {
        return ['success' => false, 'error' => $error, 'http_code' => $httpCode];
    }

    $decoded = json_decode($response, true);
    if ($decoded === null) {
        return ['success' => false, 'error' => 'Invalid JSON response', 'raw' => $response, 'http_code' => $httpCode];
    }

    $decoded['http_code'] = $httpCode;
    return $decoded;
}

/**
 * Create a new user on EylanPanel
 * Expected body fields based on common patterns + docs:
 * username, data_limit (GB), expire (timestamp or days), note, is_active, ...
 */
function eylan_create_user($namepanel, $username, $data_limit_gb, $expire_timestamp, $extra = [])
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    $body = array_merge([
        'username' => $username,
        'data_limit' => floatval($data_limit_gb), // GB
        'expire' => intval($expire_timestamp),
        'is_active' => true,
        'note' => $extra['note'] ?? '',
    ], $extra);

    // Try primary endpoint
    $result = eylan_request('POST', '/api/v1/users', $panel, $body);

    // Some versions may use different field names
    if (isset($result['success']) && $result['success'] === false && isset($result['message'])) {
        // fallback try with days instead of expire timestamp
        if (isset($extra['days'])) {
            unset($body['expire']);
            $body['days'] = intval($extra['days']);
            $result = eylan_request('POST', '/api/v1/users', $panel, $body);
        }
    }

    return $result;
}

/**
 * Get user info
 */
function eylan_get_user($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('GET', '/api/v1/users/' . urlencode($username), $panel);
}

/**
 * List all users
 */
function eylan_list_users($namepanel)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('GET', '/api/v1/users/list_all', $panel);
}

/**
 * Get subscription link / page
 */
function eylan_get_sub($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('GET', '/api/v1/users/' . urlencode($username) . '/sub', $panel);
}

/**
 * Toggle user active/inactive
 */
function eylan_toggle_user($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('POST', '/api/v1/users/' . urlencode($username) . '/toggle', $panel);
}

/**
 * Reset traffic
 */
function eylan_reset_traffic($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('POST', '/api/v1/users/' . urlencode($username) . '/reset_traffic', $panel);
}

/**
 * Revoke subscription link (generate new)
 */
function eylan_revoke($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('POST', '/api/v1/users/' . urlencode($username) . '/revoke', $panel);
}

/**
 * Delete / remove user (if endpoint exists, otherwise toggle off + note)
 */
function eylan_delete_user($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    // Try DELETE first
    $result = eylan_request('DELETE', '/api/v1/users/' . urlencode($username), $panel);
    if (isset($result['http_code']) && $result['http_code'] >= 200 && $result['http_code'] < 300) {
        return $result;
    }

    // Fallback: deactivate
    return eylan_toggle_user($namepanel, $username);
}

/**
 * Get all OpenVPN links for user
 */
function eylan_get_ovpn_links($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('GET', '/api/v1/users/' . urlencode($username) . '/all_ovpn_links', $panel);
}

/**
 * Get WireGuard files
 */
function eylan_get_wg_files($namepanel, $username)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('GET', '/api/v1/users/' . urlencode($username) . '/wg1_files', $panel);
}

/**
 * Health / status check
 */
function eylan_status($namepanel)
{
    $panel = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }

    return eylan_request('GET', '/api/v1/status', $panel);
}

} // end function_exists guard
?>
