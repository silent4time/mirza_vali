<?php
/**
 * EylanPanel API — mirza_vali v1.8.12
 * Auth: X-API-KEY = marzban_panel.password_panel
 * Protocol mode = marzban_panel.inboundid: openvpn|l2tp|cisco|wireguard|multi
 * Docs: https://eylandoo.github.io/
 */
if (!function_exists('eylan_request')) {

function eylan_request($method, $endpoint, $panel, $body = null)
{
    if (!is_array($panel) || empty($panel['url_panel'])) {
        return ['success' => false, 'error' => 'Invalid panel', 'http_code' => 0];
    }
    $url = rtrim($panel['url_panel'], '/') . $endpoint;
    $ch = curl_init();
    $opts = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json',
            'X-API-KEY: ' . ($panel['password_panel'] ?? ''),
        ],
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE);
    }
    curl_setopt_array($ch, $opts);
    $response = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($error) {
        return ['success' => false, 'error' => $error, 'http_code' => $httpCode];
    }
    $decoded = json_decode((string) $response, true);
    if (!is_array($decoded)) {
        return ['success' => false, 'error' => 'Invalid JSON', 'raw' => substr((string) $response, 0, 400), 'http_code' => $httpCode];
    }
    $decoded['http_code'] = $httpCode;
    return $decoded;
}

function eylan_get_panel($namepanel)
{
    $p = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    return (is_array($p) && !empty($p['name_panel'])) ? $p : null;
}

function eylan_normalize_protocol($raw)
{
    $p = strtolower(trim((string) $raw));
    $p = str_replace([' ', '-', '_'], '', $p);
    $map = [
        'openvpn' => 'openvpn', 'ovpn' => 'openvpn',
        'l2tp' => 'l2tp', 'ipsec' => 'l2tp', 'l2tpipsec' => 'l2tp',
        'cisco' => 'cisco', 'anyconnect' => 'cisco', 'ocserv' => 'cisco',
        'wireguard' => 'wireguard', 'wg' => 'wireguard', 'wg1' => 'wireguard',
        'multi' => 'multi', 'molti' => 'multi', 'all' => 'multi',
    ];
    return $map[$p] ?? 'multi';
}

function eylan_resolve_protocol($panel, $extra = [])
{
    if (!empty($extra['protocol'])) {
        return eylan_normalize_protocol($extra['protocol']);
    }
    if (is_array($panel) && isset($panel['inboundid']) && $panel['inboundid'] !== '' && $panel['inboundid'] !== null) {
        return eylan_normalize_protocol($panel['inboundid']);
    }
    return 'multi';
}

function eylan_protocol_flags($protocol)
{
    $protocol = eylan_normalize_protocol($protocol);
    $f = [
        'enable_openvpn' => false,
        'enable_l2tp' => false,
        'enable_cisco' => false,
        'enable_wg1' => false,
    ];
    if ($protocol === 'multi') {
        return ['enable_openvpn' => true, 'enable_l2tp' => true, 'enable_cisco' => true, 'enable_wg1' => true];
    }
    if ($protocol === 'openvpn') {
        $f['enable_openvpn'] = true;
    } elseif ($protocol === 'l2tp') {
        $f['enable_l2tp'] = true;
    } elseif ($protocol === 'cisco') {
        $f['enable_cisco'] = true;
    } elseif ($protocol === 'wireguard') {
        $f['enable_wg1'] = true;
    }
    return $f;
}

function eylan_http_ok($result)
{
    if (!is_array($result)) {
        return false;
    }
    $code = (int) ($result['http_code'] ?? 0);
    if (!empty($result['error']) && ($code === 0 || $code >= 400)) {
        return false;
    }
    if (array_key_exists('success', $result) && $result['success'] === false) {
        return false;
    }
    if ($code > 0 && ($code < 200 || $code >= 300)) {
        return false;
    }
    return true;
}

function eylan_create_user($namepanel, $username, $data_limit_gb, $expire_timestamp, $extra = [])
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    $protocol = eylan_resolve_protocol($panel, $extra);
    $flags = eylan_protocol_flags($protocol);

    $days = isset($extra['days']) ? (int) $extra['days'] : 0;
    if ($days <= 0 && $expire_timestamp > time()) {
        $days = (int) max(1, ceil(($expire_timestamp - time()) / 86400));
    }

    // فقط فیلدهای مجاز API — نه merge کور $extra (جلوگیری از لو رفتن فیلدهای اشتباه)
    $body = array_merge([
        'username' => $username,
        'data_limit' => round(floatval($data_limit_gb), 2),
        'data_limit_unit' => 'GB',
        'max_clients' => isset($extra['max_clients']) ? (int) $extra['max_clients'] : 1,
        'notes' => $extra['note'] ?? ($extra['notes'] ?? ('bot ' . date('Y-m-d H:i'))),
        'activation_type' => 'fixed_date',
    ], $flags);

    if ($days > 0) {
        $body['expiry_days'] = $days;
    } elseif ($expire_timestamp > 0) {
        $body['expiry_date_str'] = date('Y-m-d', $expire_timestamp);
    }

    // همیشه برای L2TP/Cisco رمز بساز تا در پیام کاربر داشته باشیم
    if ($flags['enable_l2tp']) {
        $body['l2tp_password'] = $extra['l2tp_password'] ?? ('L2' . bin2hex(random_bytes(4)));
    }
    if ($flags['enable_cisco']) {
        $body['cisco_password'] = $extra['cisco_password'] ?? ('C' . bin2hex(random_bytes(4)));
    }
    if ($flags['enable_wg1']) {
        // هر دو instance در صورت وجود روی پنل
        $body['wg_instances'] = $extra['wg_instances'] ?? ['wg1', 'wg2'];
        $body['allowed_wg_instances'] = $body['wg_instances'];
    }

    // JSON boolean واقعی (نه 0/1) برای API ایلان
    foreach ($flags as $fk => $fv) {
        $body[$fk] = (bool) $fv;
    }

    error_log("eylan_create_user protocol={$protocol} user={$username} flags=" . json_encode($flags));

    $result = eylan_request('POST', '/api/v1/users', $panel, $body);
    $result['_protocol'] = $protocol;
    $result['_flags'] = $flags;

    if (!eylan_http_ok($result) && $days > 0) {
        $body2 = $body;
        unset($body2['expiry_days']);
        $body2['expire'] = time() + ($days * 86400);
        $result2 = eylan_request('POST', '/api/v1/users', $panel, $body2);
        if (eylan_http_ok($result2)) {
            $result = $result2;
        }
    }

    // بعد از ساخت، حتماً با PUT پروتکل‌ها را قفل کن (API گاهی همه را پیش‌فرض روشن می‌کند)
    if (eylan_http_ok($result) || !empty($result['username']) || (isset($result['http_code']) && $result['http_code'] >= 200 && $result['http_code'] < 300)) {
        $put = $flags;
        foreach ($put as $fk => $fv) {
            $put[$fk] = (bool) $fv;
        }
        $putResult = eylan_request('PUT', '/api/v1/users/' . rawurlencode($username), $panel, $put);
        error_log("eylan_create_user PUT protocol={$protocol} http=" . ($putResult['http_code'] ?? '?'));
        $result['_put'] = $putResult;
    }

    $result['_protocol'] = $protocol;
    $result['_flags'] = $flags;
    $result['_body'] = $body;
    return $result;
}

function eylan_get_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username), $panel);
}

function eylan_get_sub($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/sub', $panel);
}

function eylan_get_ovpn_links($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/all_ovpn_links', $panel);
}

function eylan_get_wg_files($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
}

function eylan_toggle_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/toggle', $panel);
}

function eylan_reset_traffic($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/reset_traffic', $panel);
}

function eylan_revoke($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/revoke', $panel);
}

function eylan_delete_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    $r = eylan_request('DELETE', '/api/v1/users/' . rawurlencode($username), $panel);
    if (eylan_http_ok($r)) {
        return $r;
    }
    return eylan_toggle_user($namepanel, $username);
}

function eylan_status($namepanel)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/status', $panel);
}


function eylan_collect_links($data, &$out, $depth = 0)
{
    if ($depth > 6 || $data === null) {
        return;
    }
    if (is_string($data)) {
        $s = trim($data);
        if ($s === '') {
            return;
        }
        if (preg_match('#^https?://#i', $s) || preg_match('#\.ovpn#i', $s)) {
            $out[] = $s;
        } elseif (str_contains($s, '[Interface]') || str_contains($s, 'client') && str_contains($s, 'remote ')) {
            $out[] = 'RAWCFG:' . $s;
        }
        return;
    }
    if (!is_array($data)) {
        return;
    }
    foreach (['url', 'link', 'download_url', 'file_url', 'config_url', 'sub_url', 'ovpn_url', 'wg_url'] as $k) {
        if (!empty($data[$k]) && is_string($data[$k])) {
            eylan_collect_links($data[$k], $out, $depth + 1);
        }
    }
    foreach (['config', 'conf', 'content', 'wg_config', 'ovpn'] as $k) {
        if (!empty($data[$k]) && is_string($data[$k]) && strlen($data[$k]) > 20) {
            $out[] = 'RAWCFG:' . $data[$k];
        }
    }
    foreach ($data as $v) {
        if (is_array($v) || is_string($v)) {
            eylan_collect_links($v, $out, $depth + 1);
        }
    }
}

function eylan_get_wg_all_files($namepanel, $username, $user = null)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return [];
    }
    $collected = [];
    $r1 = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
    eylan_collect_links($r1, $collected);
    foreach (['wg2_files', 'all_wg_files', 'wireguard_files'] as $ep) {
        $r = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/' . $ep, $panel);
        if (is_array($r) && (eylan_http_ok($r) || !empty($r['files']) || !empty($r['configs']) || !empty($r['data']))) {
            eylan_collect_links($r, $collected);
        }
    }
    if (is_array($user)) {
        eylan_collect_links($user['wg_instances'] ?? null, $collected);
        eylan_collect_links($user['wg_files'] ?? null, $collected);
        if (!empty($user['allowed_wg_instances']) && is_array($user['allowed_wg_instances'])) {
            foreach ($user['allowed_wg_instances'] as $inst) {
                $name = is_string($inst) ? $inst : ($inst['instance'] ?? $inst['name'] ?? '');
                if ($name !== '' && $name !== 'wg1') {
                    $r = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/' . rawurlencode($name) . '_files', $panel);
                    eylan_collect_links($r, $collected);
                }
            }
        }
    }
    return array_values(array_unique($collected));
}

function eylan_get_ovpn_all($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return [];
    }
    $collected = [];
    eylan_collect_links(eylan_get_ovpn_links($namepanel, $username), $collected);
    foreach (['ovpn_links', 'openvpn_files'] as $ep) {
        eylan_collect_links(eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/' . $ep, $panel), $collected);
    }
    return array_values(array_unique($collected));
}

function eylan_fetch_psk($panel)
{
    if (!is_array($panel)) {
        return '';
    }
    $r = eylan_request('GET', '/api/v1/server_settings', $panel);
    if (!is_array($r)) {
        return '';
    }
    foreach (['ipsec_psk', 'psk', 'l2tp_psk', 'ipsec_secret', 'secret'] as $k) {
        if (!empty($r[$k]) && is_string($r[$k])) {
            return $r[$k];
        }
        if (!empty($r['data'][$k]) && is_string($r['data'][$k])) {
            return $r['data'][$k];
        }
    }
    return '';
}


/**
 * آدرس نمایشی برای کاربر — هرگز mirzavalibot را نشان نده
 */
function eylan_public_host($panel = null)
{
    // اولویت: ثابت عمومی پنل
    $public = 'panel.silentping.ir';
    if (defined('EYLAN_PUBLIC_HOST') && EYLAN_PUBLIC_HOST) {
        $public = EYLAN_PUBLIC_HOST;
    } elseif (!empty($GLOBALS['EYLAN_PUBLIC_HOST'])) {
        $public = $GLOBALS['EYLAN_PUBLIC_HOST'];
    }
    return $public;
}

function eylan_public_url($url, $panel = null)
{
    if (!is_string($url) || $url === '') {
        return $url;
    }
    $public = eylan_public_host($panel);
    // جایگزینی دامنه API داخلی
    $url = preg_replace('#https?://mirzavalibot\.silentping\.ir(:\d+)?#i', 'https://' . $public, $url);
    $url = preg_replace('#https?://[^/]*mirzavalibot[^/]*#i', 'https://' . $public, $url);
    // اگر نسبی بود
    if (!preg_match('#^https?://#i', $url)) {
        $url = 'https://' . $public . '/' . ltrim($url, '/');
    }
    return $url;
}

function eylan_vpn_server_host($panel = null)
{
    return eylan_public_host($panel);
}

function eylan_build_delivery($namepanel, $username, $protocol = null)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['subscription_url' => '', 'configs' => [], 'text' => '', 'user' => null, 'protocol' => 'multi', 'qr_payloads' => [], 'files' => []];
    }
    $protocol = $protocol !== null ? eylan_normalize_protocol($protocol) : eylan_resolve_protocol($panel, []);
    $user = eylan_get_user($namepanel, $username);
    $sub = eylan_get_sub($namepanel, $username);

    $sub_url = '';
    foreach (['sub_url', 'url', 'subscription_url'] as $k) {
        if (!empty($sub[$k]) && is_string($sub[$k])) {
            $sub_url = $sub[$k];
            break;
        }
    }
    if ($sub_url === '' && !empty($user['sub_url'])) {
        $sub_url = $user['sub_url'];
    }
    if ($sub_url !== '') {
        $sub_url = eylan_public_url($sub_url, $panel);
    }

    $server = eylan_vpn_server_host($panel);
    $files = []; // ['content'=>, 'name'=>, 'type'=>'ovpn'|'wg']
    $lines = ["✅ <b>سرویس آماده شد</b>", "یوزرنیم: <code>{$username}</code>", "نوع: <b>{$protocol}</b>"];

    $need_ovpn = in_array($protocol, ['openvpn', 'multi'], true);
    $need_l2tp = in_array($protocol, ['l2tp', 'multi'], true);
    $need_cisco = in_array($protocol, ['cisco', 'multi'], true);
    $need_wg = in_array($protocol, ['wireguard', 'multi'], true);

    if ($need_ovpn) {
        $lines[] = "\n📡 <b>OpenVPN</b>";
        if ($sub_url !== '') {
            $lines[] = "صفحه کاربری: <code>{$sub_url}</code>";
        }
        $n = 0;
        foreach (eylan_get_ovpn_all($namepanel, $username) as $item) {
            if (str_starts_with($item, 'RAWCFG:')) {
                $n++;
                $files[] = ['content' => substr($item, 7), 'name' => "{$username}_ovpn{$n}.ovpn", 'type' => 'ovpn'];
            } elseif (preg_match('#^https?://#i', $item)) {
                $n++;
                $files[] = ['content' => null, 'url' => eylan_public_url($item, $panel), 'name' => "{$username}_ovpn{$n}.ovpn", 'type' => 'ovpn'];
            }
        }
        if ($n > 0) {
            $lines[] = "فایل‌های کانفیگ (.ovpn) جداگانه ارسال می‌شوند.";
        }
    }

    if ($need_l2tp) {
        $pass = $user['l2tp_password'] ?? $user['l2tp_pass'] ?? '';
        $psk = $user['ipsec_psk'] ?? $user['l2tp_psk'] ?? $user['psk'] ?? eylan_fetch_psk($panel);
        if ($psk === '') {
            $psk = '123456';
        }
        $lines[] = "\n🛡️ <b>L2TP / IPsec</b>";
        $lines[] = "سرور: <code>{$server}</code>";
        $lines[] = "یوزرنیم: <code>{$username}</code>";
        $lines[] = $pass !== '' ? "رمز عبور: <code>{$pass}</code>" : "رمز عبور: از پنل";
        $lines[] = "Shared Key (PSK): <code>{$psk}</code>";
    }

    if ($need_cisco) {
        $pass = $user['cisco_password'] ?? $user['cisco_pass'] ?? '';
        $lines[] = "\n🌐 <b>Cisco AnyConnect</b>";
        $lines[] = "سرور: <code>{$server}</code>";
        $lines[] = "یوزرنیم: <code>{$username}</code>";
        $lines[] = $pass !== '' ? "رمز عبور: <code>{$pass}</code>" : "رمز عبور: از پنل";
    }

    if ($need_wg) {
        $lines[] = "\n🧩 <b>WireGuard</b>";
        $n = 0;
        foreach (eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null) as $item) {
            if (str_starts_with($item, 'RAWCFG:')) {
                $n++;
                $files[] = ['content' => substr($item, 7), 'name' => "{$username}_wg{$n}.conf", 'type' => 'wg'];
            } elseif (preg_match('#^https?://#i', $item)) {
                $n++;
                $files[] = ['content' => null, 'url' => eylan_public_url($item, $panel), 'name' => "{$username}_wg{$n}.conf", 'type' => 'wg'];
            }
        }
        if (!empty($user['wg1_ip'])) {
            $lines[] = "IP: <code>{$user['wg1_ip']}</code>";
        }
        if ($n > 0) {
            $lines[] = "فایل‌ها و QR هر کانفیگ جداگانه ارسال می‌شوند.";
        }
        if ($sub_url !== '' && !$need_ovpn) {
            $lines[] = "صفحه کاربری: <code>{$sub_url}</code>";
        }
    }

    if ($sub_url !== '' && !$need_ovpn && !$need_wg) {
        $lines[] = "\nصفحه کاربری: <code>{$sub_url}</code>";
    }

    return [
        'subscription_url' => $sub_url,
        'configs' => [], // دیگر لینک اضافه در configs نریز
        'text' => implode("\n", $lines),
        'user' => $user,
        'protocol' => $protocol,
        'qr_payloads' => ($sub_url !== '') ? [$sub_url] : [],
        'files' => $files,
    ];
}

function eylan_to_datauser_output($namepanel, $username, $invoice = false)
{
    global $domainhosts;
    $user = eylan_get_user($namepanel, $username);
    if (!eylan_http_ok($user) && empty($user['username'])) {
        return ['status' => 'Unsuccessful', 'msg' => $user['message'] ?? $user['error'] ?? 'User not found'];
    }
    $delivery = eylan_build_delivery($namepanel, $username);
    $sub_url = $delivery['subscription_url'];
    if ($invoice != false && !empty($domainhosts) && is_array($invoice) && !empty($invoice['id_invoice'])) {
        $sub_url = "https://{$domainhosts}/sub/" . $invoice['id_invoice'];
    }
    $data_limit_gb = floatval($user['data_limit'] ?? 0);
    $data_limit_bytes = (int) round($data_limit_gb * 1024 * 1024 * 1024);
    $used = floatval($user['download_bytes'] ?? $user['used_traffic'] ?? $user['traffic_bytes'] ?? 0);
    if ($used > 0 && $used < 10000 && $data_limit_gb > 0) {
        $used = $used * 1024 * 1024 * 1024;
    }
    $expire = 0;
    if (!empty($user['expire'])) {
        $expire = is_numeric($user['expire']) ? (int) $user['expire'] : (int) strtotime($user['expire']);
    } elseif (!empty($user['expiry_date'])) {
        $expire = (int) strtotime($user['expiry_date']);
    }
    $status = 'active';
    if ((isset($user['is_active']) && !$user['is_active']) || !empty($user['is_disabled'])) {
        $status = 'disabled';
    }
    if ($expire > 0 && $expire < time()) {
        $status = 'expired';
    }
    return [
        'status' => $status,
        'username' => $user['username'] ?? $username,
        'data_limit' => $data_limit_bytes,
        'expire' => $expire ?: null,
        'online_at' => $user['online_at'] ?? null,
        'used_traffic' => (int) $used,
        'links' => $delivery['configs'],
        'subscription_url' => $sub_url,
        'sub_updated_at' => null,
        'sub_last_user_agent' => null,
        'uuid' => null,
        'data_limit_reset' => null,
        'eylan_text' => $delivery['text'],
        'eylan_protocol' => $delivery['protocol'],
    ];
}



/**
 * ارسال مستقیم کانفیگ/رمز به کاربر تلگرام یا بله — مستقل از sendMessageService میرزا
 */
function eylan_send_to_user($chat_id, $namepanel, $username, $protocol = null, $create_body = null)
{
    usleep(1500000);
    $delivery = eylan_build_delivery($namepanel, $username, $protocol);

    // تزریق رمز ساخته‌شده هنگام create
    if (is_array($create_body)) {
        $txt = $delivery['text'];
        if (!empty($create_body['l2tp_password']) && strpos($txt, $create_body['l2tp_password']) === false) {
            $txt = preg_replace('/رمز عبور: <code>.*?<\/code>/u', 'رمز عبور: <code>' . htmlspecialchars($create_body['l2tp_password']) . '</code>', $txt, 1);
            if (strpos($txt, $create_body['l2tp_password']) === false && strpos($txt, 'L2TP') !== false) {
                $txt .= "\n🔑 L2TP: <code>{$create_body['l2tp_password']}</code>";
            }
        }
        if (!empty($create_body['cisco_password']) && strpos($txt, $create_body['cisco_password']) === false) {
            if (strpos($txt, 'Cisco') !== false) {
                $parts = explode('Cisco AnyConnect', $txt, 2);
                if (count($parts) === 2) {
                    $parts[1] = preg_replace('/رمز عبور: <code>.*?<\/code>/u', 'رمز عبور: <code>' . htmlspecialchars($create_body['cisco_password']) . '</code>', $parts[1], 1);
                    $txt = $parts[0] . 'Cisco AnyConnect' . $parts[1];
                }
            }
        }
        $delivery['text'] = $txt;
    }

    // ۱) فقط یک پیام تحویل (مشخصات + لینک صفحه کاربری)
    if (!empty($delivery['text'])) {
        sendmessage($chat_id, $delivery['text'], null, 'HTML');
    }

    // ۲) یک QR فقط برای صفحه کاربری (اگر باشد)
    $cwd = defined('BOT_ROOT') ? BOT_ROOT : sys_get_temp_dir();
    if (!empty($delivery['subscription_url']) && function_exists('createqrcode')) {
        try {
            $urlimage = rtrim($cwd, '/') . "/eylan_sub_{$chat_id}.png";
            $qr = createqrcode($delivery['subscription_url']);
            file_put_contents($urlimage, $qr->getString());
            telegram('sendphoto', [
                'chat_id' => $chat_id,
                'photo' => new CURLFile($urlimage),
                'caption' => '📱 QR صفحه کاربری',
            ]);
            @unlink($urlimage);
        } catch (Throwable $e) {
            error_log('eylan sub QR: ' . $e->getMessage());
        }
    }

    // ۳) فقط فایل‌های کانفیگ (+ QR فقط برای WireGuard)
    $fi = 0;
    foreach ($delivery['files'] as $f) {
        $fi++;
        $content = $f['content'] ?? null;
        if ($content === null && !empty($f['url'])) {
            $ch = curl_init($f['url']);
            // برای دانلود از API ممکن است نیاز به همان دامنه داخلی باشد
            $dl = $f['url'];
            // اگر public بود و شکست خورد، از url_panel هم امتحان می‌کنیم
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_FOLLOWLOCATION => true,
            ]);
            $bin = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if (!($code >= 200 && $code < 300 && is_string($bin) && strlen($bin) > 30)) {
                // retry با دامنه API پنل
                $panel = eylan_get_panel($namepanel);
                if ($panel && !empty($panel['url_panel'])) {
                    $path = parse_url($f['url'], PHP_URL_PATH);
                    $q = parse_url($f['url'], PHP_URL_QUERY);
                    $internal = rtrim($panel['url_panel'], '/') . ($path ?: '') . ($q ? ('?' . $q) : '');
                    $ch = curl_init($internal);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_TIMEOUT => 25,
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTPHEADER => ['X-API-KEY: ' . ($panel['password_panel'] ?? '')],
                    ]);
                    $bin = curl_exec($ch);
                    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    curl_close($ch);
                }
            }
            if ($code >= 200 && $code < 300 && is_string($bin) && strlen($bin) > 30) {
                $content = $bin;
            }
        }
        if ($content === null || $content === '') {
            continue;
        }
        $fname = $f['name'] ?? ("config_{$fi}.txt");
        $path = rtrim($cwd, '/') . '/' . $fname;
        file_put_contents($path, $content);
        $caption = (($f['type'] ?? '') === 'wg') ? "WireGuard #{$fi}" : "OpenVPN #{$fi}";
        telegram('senddocument', [
            'chat_id' => $chat_id,
            'document' => new CURLFile($path, 'application/octet-stream', $fname),
            'caption' => $caption,
        ]);
        // QR فقط برای کانفیگ WG (محتوای conf)
        if (($f['type'] ?? '') === 'wg' && function_exists('createqrcode')) {
            try {
                $urlimage = rtrim($cwd, '/') . "/eylan_wgqr_{$chat_id}_{$fi}.png";
                $qr = createqrcode($content);
                file_put_contents($urlimage, $qr->getString());
                telegram('sendphoto', [
                    'chat_id' => $chat_id,
                    'photo' => new CURLFile($urlimage),
                    'caption' => "QR WireGuard #{$fi}",
                ]);
                @unlink($urlimage);
            } catch (Throwable $e) {
                error_log('eylan wg qr: ' . $e->getMessage());
            }
        }
        @unlink($path);
    }

    error_log('eylan_send_to_user done chat=' . $chat_id . ' files=' . count($delivery['files']));
    return $delivery;
}


} // guard
