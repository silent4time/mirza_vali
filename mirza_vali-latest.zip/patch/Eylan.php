<?php
/**
 * EylanPanel API — mirza_vali v1.8.12
 * Auth: X-API-KEY = marzban_panel.password_panel
 * Protocol mode = marzban_panel.inboundid: openvpn|l2tp|cisco|wireguard|multi
 * Docs: https://eylandoo.github.io/
 */
if (!function_exists('eylan_request')) {

function eylan_request($method, $endpoint, $panel, $body = null)
{
    if (!is_array($panel) || empty($panel['url_panel'])) {
        return ['success' => false, 'error' => 'Invalid panel', 'http_code' => 0];
    }
    $url = rtrim($panel['url_panel'], '/') . $endpoint;
    $ch = curl_init();
    $opts = [
        CURLOPT_URL => $url,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_CONNECTTIMEOUT => 12,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_SSL_VERIFYHOST => false,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Content-Type: application/json',
            'X-API-KEY: ' . ($panel['password_panel'] ?? ''),
        ],
        CURLOPT_CUSTOMREQUEST => strtoupper($method),
    ];
    if ($body !== null) {
        $opts[CURLOPT_POSTFIELDS] = json_encode($body, JSON_UNESCAPED_UNICODE);
    }
    curl_setopt_array($ch, $opts);
    $response = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $error = curl_error($ch);
    curl_close($ch);
    if ($error) {
        return ['success' => false, 'error' => $error, 'http_code' => $httpCode];
    }
    $raw = (string) $response;
    $decoded = json_decode($raw, true);
    if (!is_array($decoded)) {
        // پاسخ متنی کانفیگ (WireGuard/OpenVPN) — دور نریز
        if ($httpCode >= 200 && $httpCode < 300 && strlen($raw) > 40) {
            if (strpos($raw, '[Interface]') !== false || stripos($raw, 'PrivateKey') !== false
                || stripos($raw, 'client') !== false || stripos($raw, 'remote ') !== false) {
                return [
                    'success' => true,
                    'http_code' => $httpCode,
                    'config' => $raw,
                    'content' => $raw,
                    '_raw_config' => true,
                ];
            }
        }
        return ['success' => false, 'error' => 'Invalid JSON', 'raw' => substr($raw, 0, 400), 'http_code' => $httpCode];
    }
    $decoded['http_code'] = $httpCode;
    return $decoded;
}

function eylan_get_panel($namepanel)
{
    $p = select("marzban_panel", "*", "name_panel", $namepanel, "select");
    return (is_array($p) && !empty($p['name_panel'])) ? $p : null;
}

function eylan_normalize_protocol($raw)
{
    $p = strtolower(trim((string) $raw));
    $p = str_replace([' ', '-', '_'], '', $p);
    $map = [
        'openvpn' => 'openvpn', 'ovpn' => 'openvpn',
        'l2tp' => 'l2tp', 'ipsec' => 'l2tp', 'l2tpipsec' => 'l2tp',
        'cisco' => 'cisco', 'anyconnect' => 'cisco', 'ocserv' => 'cisco',
        'wireguard' => 'wireguard', 'wg' => 'wireguard', 'wg1' => 'wireguard',
        'multi' => 'multi', 'molti' => 'multi', 'all' => 'multi',
    ];
    return $map[$p] ?? 'multi';
}

function eylan_resolve_protocol($panel, $extra = [])
{
    if (!empty($extra['protocol'])) {
        return eylan_normalize_protocol($extra['protocol']);
    }
    if (is_array($panel) && isset($panel['inboundid']) && $panel['inboundid'] !== '' && $panel['inboundid'] !== null) {
        return eylan_normalize_protocol($panel['inboundid']);
    }
    return 'multi';
}

function eylan_protocol_flags($protocol)
{
    $protocol = eylan_normalize_protocol($protocol);
    $f = [
        'enable_openvpn' => false,
        'enable_l2tp' => false,
        'enable_cisco' => false,
        'enable_wg1' => false,
    ];
    if ($protocol === 'multi') {
        return ['enable_openvpn' => true, 'enable_l2tp' => true, 'enable_cisco' => true, 'enable_wg1' => true];
    }
    if ($protocol === 'openvpn') {
        $f['enable_openvpn'] = true;
    } elseif ($protocol === 'l2tp') {
        $f['enable_l2tp'] = true;
    } elseif ($protocol === 'cisco') {
        $f['enable_cisco'] = true;
    } elseif ($protocol === 'wireguard') {
        $f['enable_wg1'] = true;
    }
    return $f;
}

function eylan_http_ok($result)
{
    if (!is_array($result)) {
        return false;
    }
    $code = (int) ($result['http_code'] ?? 0);
    if (!empty($result['error']) && ($code === 0 || $code >= 400)) {
        return false;
    }
    if (array_key_exists('success', $result) && $result['success'] === false) {
        return false;
    }
    if ($code > 0 && ($code < 200 || $code >= 300)) {
        return false;
    }
    return true;
}

function eylan_create_user($namepanel, $username, $data_limit_gb, $expire_timestamp, $extra = [])
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    $protocol = eylan_resolve_protocol($panel, $extra);
    $flags = eylan_protocol_flags($protocol);

    $days = isset($extra['days']) ? (int) $extra['days'] : 0;
    if ($days <= 0 && $expire_timestamp > time()) {
        $days = (int) max(1, ceil(($expire_timestamp - time()) / 86400));
    }

    // فقط فیلدهای مجاز API — نه merge کور $extra (جلوگیری از لو رفتن فیلدهای اشتباه)
    $body = array_merge([
        'username' => $username,
        'data_limit' => round(floatval($data_limit_gb), 2),
        'data_limit_unit' => 'GB',
        'max_clients' => isset($extra['max_clients']) ? (int) $extra['max_clients'] : 1,
        'notes' => $extra['note'] ?? ($extra['notes'] ?? ('bot ' . date('Y-m-d H:i'))),
        'activation_type' => 'fixed_date',
    ], $flags);

    if ($days > 0) {
        $body['expiry_days'] = $days;
    } elseif ($expire_timestamp > 0) {
        $body['expiry_date_str'] = date('Y-m-d', $expire_timestamp);
    }

    // همیشه برای L2TP/Cisco رمز بساز تا در پیام کاربر داشته باشیم
    if ($flags['enable_l2tp']) {
        $body['l2tp_password'] = $extra['l2tp_password'] ?? ('L2' . bin2hex(random_bytes(4)));
    }
    if ($flags['enable_cisco']) {
        $body['cisco_password'] = $extra['cisco_password'] ?? ('C' . bin2hex(random_bytes(4)));
    }
    if ($flags['enable_wg1']) {
        // هر دو instance در صورت وجود روی پنل
        $body['wg_instances'] = $extra['wg_instances'] ?? ['wg1', 'wg2'];
        $body['allowed_wg_instances'] = $body['wg_instances'];
        $body['enable_wg1'] = true;
    }

    // JSON boolean واقعی (نه 0/1) برای API ایلان
    foreach ($flags as $fk => $fv) {
        $body[$fk] = (bool) $fv;
    }

    error_log("eylan_create_user protocol={$protocol} user={$username} flags=" . json_encode($flags));

    $result = eylan_request('POST', '/api/v1/users', $panel, $body);
    $result['_protocol'] = $protocol;
    $result['_flags'] = $flags;

    if (!eylan_http_ok($result) && $days > 0) {
        $body2 = $body;
        unset($body2['expiry_days']);
        $body2['expire'] = time() + ($days * 86400);
        $result2 = eylan_request('POST', '/api/v1/users', $panel, $body2);
        if (eylan_http_ok($result2)) {
            $result = $result2;
        }
    }

    // بعد از ساخت، حتماً با PUT پروتکل‌ها را قفل کن (API گاهی همه را پیش‌فرض روشن می‌کند)
    if (eylan_http_ok($result) || !empty($result['username']) || (isset($result['http_code']) && $result['http_code'] >= 200 && $result['http_code'] < 300)) {
        $put = $flags;
        foreach ($put as $fk => $fv) {
            $put[$fk] = (bool) $fv;
        }
        $putResult = eylan_request('PUT', '/api/v1/users/' . rawurlencode($username), $panel, $put);
        error_log("eylan_create_user PUT protocol={$protocol} http=" . ($putResult['http_code'] ?? '?'));
        $result['_put'] = $putResult;
    }

    $result['_protocol'] = $protocol;
    $result['_flags'] = $flags;
    $result['_body'] = $body;
    return $result;
}

function eylan_get_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username), $panel);
}

function eylan_get_sub($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/sub', $panel);
}

function eylan_get_ovpn_links($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/all_ovpn_links', $panel);
}

function eylan_get_wg_files($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
}

function eylan_toggle_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/toggle', $panel);
}

function eylan_reset_traffic($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/reset_traffic', $panel);
}

function eylan_revoke($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('POST', '/api/v1/users/' . rawurlencode($username) . '/revoke', $panel);
}

function eylan_delete_user($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    $r = eylan_request('DELETE', '/api/v1/users/' . rawurlencode($username), $panel);
    if (eylan_http_ok($r)) {
        return $r;
    }
    return eylan_toggle_user($namepanel, $username);
}

function eylan_status($namepanel)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['success' => false, 'message' => 'Panel not found'];
    }
    return eylan_request('GET', '/api/v1/status', $panel);
}


function eylan_collect_links($data, &$out, $depth = 0)
{
    if ($depth > 6 || $data === null) {
        return;
    }
    if (is_string($data)) {
        $s = trim($data);
        if ($s === '') {
            return;
        }
        if (preg_match('#^https?://#i', $s) || preg_match('#\.ovpn#i', $s) || preg_match('#\.conf#i', $s) || str_contains($s, 'wg')) {
            $out[] = $s;
        } elseif (str_contains($s, '[Interface]') || str_contains($s, 'client') && str_contains($s, 'remote ')) {
            $out[] = 'RAWCFG:' . $s;
        }
        return;
    }
    if (!is_array($data)) {
        return;
    }
    foreach (['url', 'link', 'download_url', 'file_url', 'config_url', 'sub_url', 'ovpn_url', 'wg_url'] as $k) {
        if (!empty($data[$k]) && is_string($data[$k])) {
            eylan_collect_links($data[$k], $out, $depth + 1);
        }
    }
    foreach (['config', 'conf', 'content', 'wg_config', 'ovpn'] as $k) {
        if (!empty($data[$k]) && is_string($data[$k]) && strlen($data[$k]) > 20) {
            $out[] = 'RAWCFG:' . $data[$k];
        }
    }
    foreach ($data as $v) {
        if (is_array($v) || is_string($v)) {
            eylan_collect_links($v, $out, $depth + 1);
        }
    }
}

function eylan_get_ovpn_all($namepanel, $username)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return [];
    }
    $collected = [];
    eylan_collect_links(eylan_get_ovpn_links($namepanel, $username), $collected);
    foreach (['ovpn_links', 'openvpn_files'] as $ep) {
        eylan_collect_links(eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/' . $ep, $panel), $collected);
    }
    return array_values(array_unique($collected));
}

function eylan_fetch_psk($panel)
{
    if (!is_array($panel)) {
        return '';
    }
    $r = eylan_request('GET', '/api/v1/server_settings', $panel);
    if (!is_array($r)) {
        return '';
    }
    foreach (['ipsec_psk', 'psk', 'l2tp_psk', 'ipsec_secret', 'secret'] as $k) {
        if (!empty($r[$k]) && is_string($r[$k])) {
            return $r[$k];
        }
        if (!empty($r['data'][$k]) && is_string($r['data'][$k])) {
            return $r['data'][$k];
        }
    }
    return '';
}


/**
 * آدرس نمایشی برای کاربر — هرگز mirzavalibot را نشان نده
 */

/**
 * آدرس عمومی پنل برای کاربر
 * لینک درست: http://panel.silentping.ir:8050/...
 * هرگز mirzavalibot و هرگز بدون پورت 8050
 */
function eylan_get_wg_all_files($namepanel, $username, $user = null)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return [];
    }
    if (!is_array($user)) {
        $user = eylan_get_user($namepanel, $username);
    }
    $base = rtrim($panel['url_panel'] ?? '', '/');
    $rawOut = [];
    $seenEp = [];

    $addConf = function ($body, $src) use (&$rawOut, &$seenEp) {
        if (!is_string($body) || $body === '') {
            return;
        }
        if (strpos($body, '[Interface]') === false && strpos($body, '\\[Interface\\]') !== false) {
            $body = stripcslashes($body);
        }
        if (preg_match_all('/\[Interface\][\s\S]*?(?=(?:\[Interface\]|\z))/i', $body, $blocks)) {
            foreach ($blocks[0] as $block) {
                $block = trim($block);
                if (stripos($block, 'PrivateKey') === false) {
                    continue;
                }
                $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $block, $m) ? strtolower(rtrim($m[1], '\\')) : md5($block);
                if (isset($seenEp[$ep])) {
                    continue;
                }
                $seenEp[$ep] = true;
                $rawOut[] = 'RAWCFG:' . $block;
                error_log("eylan_wg add from=$src endpoint=$ep");
            }
        } elseif (strpos($body, '[Interface]') !== false && stripos($body, 'PrivateKey') !== false) {
            $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? strtolower($m[1]) : md5($body);
            if (!isset($seenEp[$ep])) {
                $seenEp[$ep] = true;
                $rawOut[] = 'RAWCFG:' . $body;
                error_log("eylan_wg add from=$src endpoint=$ep");
            }
        }
    };

    $walk = function ($data, $src, $depth = 0) use (&$walk, $addConf) {
        if ($depth > 14 || $data === null) {
            return;
        }
        if (is_string($data)) {
            if (strpos($data, 'PrivateKey') !== false || strpos($data, '[Interface]') !== false) {
                $addConf($data, $src);
            }
            return;
        }
        if (!is_array($data)) {
            return;
        }
        foreach ($data as $k => $v) {
            if (is_string($v) || is_array($v)) {
                $walk($v, $src . '.' . $k, $depth + 1);
            }
        }
    };

    // token
    $token = '';
    $su = is_array($user) ? ($user['sub_url'] ?? '') : '';
    if ($su === '') {
        $sub = eylan_get_sub($namepanel, $username);
        if (is_array($sub)) {
            $su = $sub['sub_url'] ?? $sub['url'] ?? '';
        }
    }
    if (preg_match('#/sub/([^/]+)/#', (string) $su, $m)) {
        $token = $m[1];
    }

    // --- endpoints discovered from subpage JS ---
    $gets = [
        '/get_user_data/' . rawurlencode($username),
        '/get_user_connections/' . rawurlencode($username),
        '/get_subpage_download_data/',
        '/get_subpage_download_data/' . rawurlencode($username),
    ];
    if ($token !== '') {
        $gets[] = '/get_subpage_download_data/?token=' . rawurlencode($token) . '&username=' . rawurlencode($username);
        $gets[] = '/get_user_data/' . rawurlencode($username) . '?token=' . rawurlencode($token);
    }
    foreach ($gets as $path) {
        $raw = eylan_http_get_raw($base . $path, $panel);
        $body = $raw['body'] ?? '';
        if (is_string($body) && $body !== '') {
            error_log('eylan_wg GET ' . $path . ' http=' . ($raw['code'] ?? 0) . ' len=' . strlen($body));
            $addConf($body, 'GET:' . $path);
            $j = json_decode($body, true);
            if (is_array($j)) {
                $walk($j, 'GET:' . $path);
            }
        }
        $res = eylan_request('GET', $path, $panel);
        if (is_array($res)) {
            if (!empty($res['raw']) && is_string($res['raw'])) {
                $addConf($res['raw'], 'REQ:' . $path);
                $j = json_decode($res['raw'], true);
                if (is_array($j)) {
                    $walk($j, 'REQ:' . $path);
                }
            }
            $walk($res, 'REQ:' . $path);
        }
    }

    // POST get_subpage_download_data
    foreach ([
        ['token' => $token, 'username' => $username],
        ['username' => $username, 'token' => $token],
        ['username' => $username],
    ] as $pb) {
        if ($token === '' && array_key_exists('token', $pb) && ($pb['token'] ?? '') === '') {
            continue;
        }
        $ch = curl_init($base . '/get_subpage_download_data/');
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => json_encode($pb),
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Accept: application/json',
                'X-API-KEY: ' . ($panel['password_panel'] ?? ''),
            ],
            CURLOPT_SSL_VERIFYPEER => false,
        ]);
        $body = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code >= 200 && $code < 300 && is_string($body) && $body !== '') {
            $addConf($body, 'POST:download_data');
            $j = json_decode($body, true);
            if (is_array($j)) {
                $walk($j, 'POST:download_data');
            }
        }
    }

    // classic wg1_files
    $urls = [];
    $r1 = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
    if (is_array($r1)) {
        eylan_extract_wg_download_urls($r1, $base, $urls, $token);
        $walk($r1, 'wg1_files');
    }
    if (is_array($user) && !empty($user['wg_instances']) && $token !== '') {
        foreach ($user['wg_instances'] as $instRow) {
            if (!is_array($instRow)) {
                continue;
            }
            $inst = $instRow['instance'] ?? 'wg1';
            foreach (($instRow['servers'] ?? []) as $srv) {
                if (!is_array($srv)) {
                    continue;
                }
                $eid = (string) ($srv['endpoint_id'] ?? '');
                $stype = $srv['server_type'] ?? 'main_tunnel';
                if ($eid === '') {
                    continue;
                }
                $urls[] = $base . '/download_' . $inst . '/' . $token . '/' . rawurlencode($username) . '/' . $stype . '/' . $eid;
            }
        }
    }
    foreach ($urls as $u) {
        if (is_string($u) && str_contains($u, '/download_wg1/')) {
            $urls[] = str_replace('/download_wg1/', '/download_wg2/', $u);
        }
    }
    $seenU = [];
    foreach ($urls as $u) {
        if (!is_string($u) || !preg_match('#^https?://.*/download_wg\d+/#i', $u)) {
            continue;
        }
        $k = preg_replace('#^https?://[^/]+#i', '', $u);
        if (isset($seenU[$k])) {
            continue;
        }
        $seenU[$k] = true;
        $addConf(eylan_http_get_body($u, $panel), $u);
    }

    error_log('eylan_get_wg_all_files user=' . $username . ' confs=' . count($rawOut) . ' token=' . $token);
    return $rawOut;
}


function eylan_extract_wg_download_urls($data, $base, &$collected, &$token, $depth = 0)
{
    if ($depth > 8 || $data === null) {
        return;
    }
    if (is_string($data)) {
        $s = trim($data);
        if (preg_match('#/download_wg\d+/#i', $s)) {
            if (!preg_match('#^https?://#i', $s)) {
                $s = $base . '/' . ltrim($s, '/');
            }
            $collected[] = $s;
            if ($token === '' && preg_match('#/download_wg\d+/([a-f0-9]+)/#i', $s, $m)) {
                $token = $m[1];
            }
        } elseif (preg_match('#^https?://[^\s]+#i', $s) && (str_contains($s, 'download_wg') || str_ends_with($s, '.conf'))) {
            $collected[] = $s;
        }
        return;
    }
    if (!is_array($data)) {
        return;
    }
    // فیلدهای رایج
    foreach (['url', 'download_url', 'file_url', 'link', 'href', 'path'] as $k) {
        if (!empty($data[$k])) {
            eylan_extract_wg_download_urls($data[$k], $base, $collected, $token, $depth + 1);
        }
    }
    foreach ($data as $k => $v) {
        if (is_array($v) || is_string($v)) {
            eylan_extract_wg_download_urls($v, $base, $collected, $token, $depth + 1);
        }
    }
}


function eylan_collect_wg_raw($data, &$out, $depth = 0)
{
    if ($depth > 8 || $data === null) {
        return;
    }
    if (is_string($data)) {
        $s = trim($data);
        if (strlen($s) > 40 && (strpos($s, '[Interface]') !== false || (stripos($s, 'PrivateKey') !== false && stripos($s, 'Endpoint') !== false))) {
            $out[] = 'RAWCFG:' . $s;
        }
        return;
    }
    if (!is_array($data)) {
        return;
    }
    foreach (['config', 'conf', 'content', 'wg_config', 'wireguard_config', 'client_config', 'file_content', 'text'] as $k) {
        if (!empty($data[$k]) && is_string($data[$k])) {
            eylan_collect_wg_raw($data[$k], $out, $depth + 1);
        }
    }
    foreach ($data as $v) {
        if (is_array($v) || is_string($v)) {
            eylan_collect_wg_raw($v, $out, $depth + 1);
        }
    }
}

function eylan_http_get_raw($url, $panel = null, $extra_headers = [])
{
    if (!is_string($url) || $url === '') {
        return ['code' => 0, 'body' => ''];
    }
    $attempts = [];
    if (is_array($panel) && !empty($panel['password_panel'])) {
        $attempts[] = array_merge(['X-API-KEY: ' . $panel['password_panel'], 'Accept: application/json, text/plain, */*'], $extra_headers);
    }
    $attempts[] = array_merge(['Accept: application/json, text/plain, */*'], $extra_headers);

    foreach ($attempts as $hdrs) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT => 25,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTPHEADER => $hdrs,
            CURLOPT_USERAGENT => 'mirza_vali/1.8.36',
        ]);
        $bin = curl_exec($ch);
        $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        if ($code >= 200 && $code < 300 && is_string($bin)) {
            return ['code' => $code, 'body' => $bin];
        }
        // keep last non-empty error body for debug
        if (is_string($bin) && $bin !== '' && $code > 0) {
            $last = ['code' => $code, 'body' => $bin];
        }
    }
    return $last ?? ['code' => 0, 'body' => ''];
}

function eylan_http_get_body($url, $panel = null)
{
    $r = eylan_http_get_raw($url, $panel);
    $bin = $r['body'] ?? '';
    if (!is_string($bin) || $bin === '') {
        return '';
    }
    // برای دانلود conf سخت‌گیر؛ برای JSON خام از eylan_http_get_raw استفاده شود
    if (strpos($bin, '[Interface]') !== false || stripos($bin, 'PrivateKey') !== false
        || (stripos($bin, 'client') !== false && stripos($bin, 'remote') !== false)) {
        return $bin;
    }
    return '';
}



/**
 * از HTML صفحه ساب، لینک/متن کانفیگ‌های WG را دربیار
 * (Armenia :5182 و Turkey :5183 و هر Endpoint دیگر)
 */
function eylan_parse_wg_from_html($html, &$out, $panel = null, $username = '')
{
    // لینک‌های .conf
    if (preg_match_all('#https?://[^\s"\'<>]+?\.conf(?:\?[^\s"\'<>]*)?#i', $html, $m)) {
        foreach ($m[0] as $u) {
            $out[] = $u;
        }
    }
    // href نسبی
    if (preg_match_all('#href=["\']([^"\']+\.conf[^"\']*)["\']#i', $html, $m)) {
        foreach ($m[1] as $u) {
            if (!preg_match('#^https?://#i', $u) && is_array($panel)) {
                $u = rtrim($panel['url_panel'], '/') . '/' . ltrim($u, '/');
            }
            $out[] = $u;
        }
    }
    // API download paths در صفحه
    if (preg_match_all('#(/api/v1/users/[^"\'\s]+/(?:wg\d*_files|[^"\'\s]*config[^"\'\s]*))#i', $html, $m)) {
        foreach ($m[1] as $path) {
            if (is_array($panel)) {
                $body = eylan_http_get_body(rtrim($panel['url_panel'], '/') . $path, $panel);
                if ($body !== '' && (strpos($body, '[Interface]') !== false || stripos($body, 'PrivateKey') !== false)) {
                    $out[] = 'RAWCFG:' . $body;
                } else {
                    // maybe JSON
                    $j = json_decode($body, true);
                    if (is_array($j)) {
                        eylan_collect_links($j, $out);
                        eylan_collect_wg_raw($j, $out);
                    }
                }
            }
        }
    }
    // بلوک‌های conf داخل صفحه / اسکریپت
    if (preg_match_all('#\[Interface\][\s\S]{20,2000}?\[Peer\][\s\S]{20,1500}?(?=\\[Interface\\]|</|$)#i', $html, $m)) {
        foreach ($m[0] as $block) {
            $block = html_entity_decode(strip_tags($block));
            if (stripos($block, 'PrivateKey') !== false || stripos($block, 'Endpoint') !== false) {
                $out[] = 'RAWCFG:' . trim($block);
            }
        }
    }
    // data-config / data-conf attributes
    if (preg_match_all('#data-(?:config|conf|wg)=["\']([^"\']+)["\']#i', $html, $m)) {
        foreach ($m[1] as $raw) {
            $dec = html_entity_decode($raw);
            if (strpos($dec, '[Interface]') !== false) {
                $out[] = 'RAWCFG:' . $dec;
            } elseif (preg_match('#^https?://#i', $dec) || str_contains($dec, '.conf')) {
                $out[] = $dec;
            }
        }
    }
}


function eylan_public_base()
{
    if (defined('EYLAN_PUBLIC_BASE') && EYLAN_PUBLIC_BASE) {
        return rtrim(EYLAN_PUBLIC_BASE, '/');
    }
    if (!empty($GLOBALS['EYLAN_PUBLIC_BASE'])) {
        return rtrim((string) $GLOBALS['EYLAN_PUBLIC_BASE'], '/');
    }
    return 'http://panel.silentping.ir:8050';
}

function eylan_public_host($panel = null)
{
    // فقط hostname برای L2TP/Cisco (بدون پورت)
    return 'panel.silentping.ir';
}

function eylan_public_url($url, $panel = null)
{
    if (!is_string($url) || $url === '') {
        return $url;
    }
    $base = eylan_public_base(); // http://panel.silentping.ir:8050

    // استخراج path+query
    $path = '';
    if (preg_match('#^https?://[^/]+(/.*)$#', $url, $m)) {
        $path = $m[1];
    } elseif (preg_match('#^https?://[^/]+$#', $url)) {
        $path = '/';
    } else {
        $path = '/' . ltrim($url, '/');
    }

    // اگر از قبل base درست بود
    if (str_starts_with($url, $base)) {
        return $url;
    }

    // هر دامنه mirzavalibot یا panel بدون پورت / با https اشتباه → base صحیح
    if (preg_match('#mirzavalibot#i', $url) || preg_match('#panel\.silentping\.ir#i', $url) || preg_match('#^https?://#i', $url)) {
        return $base . $path;
    }

    return $base . $path;
}

function eylan_vpn_server_host($panel = null)
{
    return eylan_public_host($panel);
}

function eylan_build_delivery($namepanel, $username, $protocol = null)
{
    $panel = eylan_get_panel($namepanel);
    if (!$panel) {
        return ['subscription_url' => '', 'configs' => [], 'text' => '', 'user' => null, 'protocol' => 'multi', 'qr_payloads' => [], 'files' => []];
    }
    $protocol = $protocol !== null ? eylan_normalize_protocol($protocol) : eylan_resolve_protocol($panel, []);
    $user = eylan_get_user($namepanel, $username);
    $sub = eylan_get_sub($namepanel, $username);

    $sub_url = '';
    foreach (['sub_url', 'url', 'subscription_url'] as $k) {
        if (!empty($sub[$k]) && is_string($sub[$k])) {
            $sub_url = $sub[$k];
            break;
        }
    }
    if ($sub_url === '' && !empty($user['sub_url'])) {
        $sub_url = $user['sub_url'];
    }
    if ($sub_url !== '') {
        $sub_url = eylan_public_url($sub_url, $panel);
    }

    $server = eylan_vpn_server_host($panel);
    $files = []; // ['content'=>, 'name'=>, 'type'=>'ovpn'|'wg']
    $lines = ["✅ <b>سرویس آماده شد</b>", "یوزرنیم: <code>{$username}</code>", "نوع: <b>{$protocol}</b>"];

    $need_ovpn = in_array($protocol, ['openvpn', 'multi'], true);
    $need_l2tp = in_array($protocol, ['l2tp', 'multi'], true);
    $need_cisco = in_array($protocol, ['cisco', 'multi'], true);
    $need_wg = in_array($protocol, ['wireguard', 'multi'], true);

    if ($need_ovpn) {
        $lines[] = "\n📡 <b>OpenVPN</b>";
        if ($sub_url !== '') {
            $lines[] = "صفحه کاربری: <code>{$sub_url}</code>";
        }
        $n = 0;
        foreach (eylan_get_ovpn_all($namepanel, $username) as $item) {
            if (str_starts_with($item, 'RAWCFG:')) {
                $n++;
                $files[] = ['content' => substr($item, 7), 'name' => "{$username}_ovpn{$n}.ovpn", 'type' => 'ovpn'];
            } elseif (preg_match('#^https?://#i', $item)) {
                $n++;
                $files[] = ['content' => null, 'url' => $item, 'name' => "{$username}_ovpn{$n}.ovpn", 'type' => 'ovpn'];
            }
        }
        if ($n > 0) {
            $lines[] = "فایل‌های کانفیگ (.ovpn) جداگانه ارسال می‌شوند.";
        }
    }

    if ($need_l2tp) {
        $pass = $user['l2tp_password'] ?? $user['l2tp_pass'] ?? '';
        $psk = $user['ipsec_psk'] ?? $user['l2tp_psk'] ?? $user['psk'] ?? eylan_fetch_psk($panel);
        if ($psk === '') {
            $psk = '123456';
        }
        $lines[] = "\n🛡️ <b>L2TP / IPsec</b>";
        $lines[] = "سرور: <code>{$server}</code>";
        $lines[] = "یوزرنیم: <code>{$username}</code>";
        $lines[] = $pass !== '' ? "رمز عبور: <code>{$pass}</code>" : "رمز عبور: از پنل";
        $lines[] = "Shared Key (PSK): <code>{$psk}</code>";
    }

    if ($need_cisco) {
        $pass = $user['cisco_password'] ?? $user['cisco_pass'] ?? '';
        $lines[] = "\n🌐 <b>Cisco AnyConnect</b>";
        $lines[] = "سرور: <code>{$server}</code>";
        $lines[] = "یوزرنیم: <code>{$username}</code>";
        $lines[] = $pass !== '' ? "رمز عبور: <code>{$pass}</code>" : "رمز عبور: از پنل";
    }

    if ($need_wg) {
        $lines[] = "\n🧩 <b>WireGuard</b>";
        $n = 0;
        foreach (eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null) as $item) {
            if (str_starts_with($item, 'RAWCFG:')) {
                $n++;
                $files[] = ['content' => substr($item, 7), 'name' => "{$username}_wg{$n}.conf", 'type' => 'wg'];
            } elseif (preg_match('#^https?://#i', $item)) {
                $n++;
                $files[] = ['content' => null, 'url' => $item, 'name' => "{$username}_wg{$n}.conf", 'type' => 'wg'];
            }
        }
        if (!empty($user['wg1_ip'])) {
            $lines[] = "IP: <code>{$user['wg1_ip']}</code>";
        }
        if ($n > 0) {
            $lines[] = "فایل‌ها و QR هر کانفیگ جداگانه ارسال می‌شوند.";
        }
        if ($sub_url !== '' && !$need_ovpn) {
            $lines[] = "صفحه کاربری: <code>{$sub_url}</code>";
        }
    }

    if ($sub_url !== '' && !$need_ovpn && !$need_wg) {
        $lines[] = "\nصفحه کاربری: <code>{$sub_url}</code>";
    }

    return [
        'subscription_url' => $sub_url,
        'configs' => [], // دیگر لینک اضافه در configs نریز
        'text' => implode("\n", $lines),
        'user' => $user,
        'protocol' => $protocol,
        'qr_payloads' => ($sub_url !== '') ? [$sub_url] : [],
        'files' => $files,
    ];
}

function eylan_to_datauser_output($namepanel, $username, $invoice = false)
{
    global $domainhosts;
    $user = eylan_get_user($namepanel, $username);
    if (!eylan_http_ok($user) && empty($user['username'])) {
        return ['status' => 'Unsuccessful', 'msg' => $user['message'] ?? $user['error'] ?? 'User not found'];
    }
    $delivery = eylan_build_delivery($namepanel, $username);
    $sub_url = $delivery['subscription_url'];
    if ($invoice != false && !empty($domainhosts) && is_array($invoice) && !empty($invoice['id_invoice'])) {
        $sub_url = "https://{$domainhosts}/sub/" . $invoice['id_invoice'];
    }
    $data_limit_gb = floatval($user['data_limit'] ?? 0);
    $data_limit_bytes = (int) round($data_limit_gb * 1024 * 1024 * 1024);
    $used = floatval($user['download_bytes'] ?? $user['used_traffic'] ?? $user['traffic_bytes'] ?? 0);
    if ($used > 0 && $used < 10000 && $data_limit_gb > 0) {
        $used = $used * 1024 * 1024 * 1024;
    }
    $expire = 0;
    if (!empty($user['expire'])) {
        $expire = is_numeric($user['expire']) ? (int) $user['expire'] : (int) strtotime($user['expire']);
    } elseif (!empty($user['expiry_date'])) {
        $expire = (int) strtotime($user['expiry_date']);
    }
    $status = 'active';
    if ((isset($user['is_active']) && !$user['is_active']) || !empty($user['is_disabled'])) {
        $status = 'disabled';
    }
    if ($expire > 0 && $expire < time()) {
        $status = 'expired';
    }
    return [
        'status' => $status,
        'username' => $user['username'] ?? $username,
        'data_limit' => $data_limit_bytes,
        'expire' => $expire ?: null,
        'online_at' => $user['online_at'] ?? null,
        'used_traffic' => (int) $used,
        'links' => $delivery['configs'],
        'subscription_url' => $sub_url,
        'sub_updated_at' => null,
        'sub_last_user_agent' => null,
        'uuid' => null,
        'data_limit_reset' => null,
        'eylan_text' => $delivery['text'],
        'eylan_protocol' => $delivery['protocol'],
    ];
}



/**
 * ارسال مستقیم کانفیگ/رمز به کاربر تلگرام یا بله — مستقل از sendMessageService میرزا
 */

function eylan_lock($key)
{
    $dir = sys_get_temp_dir() . '/mv_eylan_lock';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $f = $dir . '/' . md5($key) . '.lock';
    if (is_file($f) && (time() - filemtime($f)) < 180) {
        error_log('eylan_lock SKIP ' . $key);
        return false;
    }
    @file_put_contents($f, (string) time());
    return true;
}


/**
 * یک پیام واحد موفقیت برای ایلان (به‌جای afterPay + پیام دوم)
 */
function eylan_format_success_message($username, $product_name, $location, $days, $volume, $protocol, $sub_url, $namepanel = null, $create_body = null)
{
    $protocol = eylan_normalize_protocol($protocol);
    $sub_url = $sub_url ? eylan_public_url($sub_url) : '';
    $icons = [
        'openvpn' => '📡 OpenVPN',
        'wireguard' => '🧩 WireGuard',
        'l2tp' => '🛡️ L2TP / IPsec',
        'cisco' => '🌐 Cisco AnyConnect',
        'multi' => '🛰️ Multi',
    ];
    $proto_line = $icons[$protocol] ?? ('🛰️ ' . $protocol);

    $days_label = (strval($days) === '0' || $days === 0 || $days === 'نامحدود') ? 'نامحدود' : $days;
    $vol_label = (strval($volume) === '0' || $volume === 0 || $volume === 'نامحدود') ? 'نامحدود' : $volume;

    $lines = [];
    $lines[] = "✅ <b>سرویس با موفقیت ایجاد شد</b>";
    $lines[] = "";
    $lines[] = $proto_line;
    $lines[] = "";
    $lines[] = "👤 نام کاربری سرویس : <code>{$username}</code>";
    $lines[] = "🌿 نام سرویس: {$product_name}";
    $lines[] = "🇺🇳 لوکیشن: {$location}";
    $lines[] = "⏳ مدت زمان: {$days_label} روز";
    $lines[] = "🗜 حجم سرویس: {$vol_label} گیگابایت";
    $lines[] = "";
    $lines[] = "یوزرنیم: <code>{$username}</code>";

    // L2TP / Cisco credentials
    if (in_array($protocol, ['l2tp', 'multi', 'cisco'], true) && $namepanel) {
        $panel = eylan_get_panel($namepanel);
        $user = eylan_get_user($namepanel, $username);
        if (!is_array($user)) {
            $user = [];
        }
        $server = eylan_vpn_server_host($panel);
        if (in_array($protocol, ['l2tp', 'multi'], true)) {
            $pass = $user['l2tp_password'] ?? $user['l2tp_pass'] ?? ($create_body['l2tp_password'] ?? '');
            $psk = $user['ipsec_psk'] ?? $user['l2tp_psk'] ?? $user['psk'] ?? eylan_fetch_psk($panel);
            if ($psk === '') {
                $psk = '123456';
            }
            $lines[] = "";
            $lines[] = "🛡️ <b>L2TP / IPsec</b>";
            $lines[] = "سرور: <code>{$server}</code>";
            $lines[] = $pass !== '' ? "رمز عبور: <code>{$pass}</code>" : "رمز عبور: از پنل";
            $lines[] = "Shared Key (PSK): <code>{$psk}</code>";
        }
        if (in_array($protocol, ['cisco', 'multi'], true)) {
            $pass = $user['cisco_password'] ?? $user['cisco_pass'] ?? ($create_body['cisco_password'] ?? '');
            $lines[] = "";
            $lines[] = "🌐 <b>Cisco AnyConnect</b>";
            $lines[] = "سرور: <code>{$server}</code>";
            $lines[] = $pass !== '' ? "رمز عبور: <code>{$pass}</code>" : "رمز عبور: از پنل";
        }
    }

    if ($sub_url !== '') {
        $lines[] = "";
        $lines[] = "صفحه کاربری:";
        $lines[] = "<code>{$sub_url}</code>";
    }

    if (in_array($protocol, ['openvpn', 'multi'], true)) {
        $lines[] = "";
        $lines[] = "فایل‌های کانفیگ (.ovpn) جداگانه ارسال می‌شوند.";
    }
    if (in_array($protocol, ['wireguard', 'multi'], true)) {
        $lines[] = "";
        $lines[] = "فایل و QR وایرگارد جداگانه ارسال می‌شوند.";
    }

    $lines[] = "";
    $lines[] = "🧑‍🦯 شما میتوانید شیوه اتصال را با فشردن دکمه زیر و انتخاب سیستم عامل خود را دریافت کنید";

    return implode("\n", $lines);
}

/** سازگاری با کد قبلی */
function eylan_credentials_append($text, $namepanel, $username, $protocol, $create_body = null)
{
    // دیگر به afterPay چیزی اضافه نکن — پیام واحد از eylan_format_success_message می‌آید
    return $text;
}

function eylan_send_to_user($chat_id, $namepanel, $username, $protocol = null, $create_body = null)
{
    if (!eylan_lock("files|" . $username . "|" . $namepanel)) {
        return null;
    }
    usleep(1500000); // صبر بیشتر برای ساخت فایل‌های WG/OVPN
    $delivery = eylan_build_delivery($namepanel, $username, $protocol);

    // پیام متنی اینجا ارسال نمی‌شود — فقط فایل (پیام afterPay از function.php می‌آید)
    // بدون QR صفحه کاربری — فقط فایل کانفیگ (+ QR برای WireGuard)
    $cwd = defined('BOT_ROOT') ? BOT_ROOT : sys_get_temp_dir();

    $fi = 0;
    foreach ($delivery['files'] as $f) {
        $fi++;
        $content = $f['content'] ?? null;
        if ($content === null && !empty($f['url'])) {
            $ch = curl_init($f['url']);
            // برای دانلود از API ممکن است نیاز به همان دامنه داخلی باشد
            $dl = $f['url'];
            // اگر public بود و شکست خورد، از url_panel هم امتحان می‌کنیم
            curl_setopt_array($ch, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT => 25,
                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_FOLLOWLOCATION => true,
            ]);
            $bin = curl_exec($ch);
            $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            if (!($code >= 200 && $code < 300 && is_string($bin) && strlen($bin) > 30)) {
                // retry با دامنه API پنل
                $panel = eylan_get_panel($namepanel);
                if ($panel && !empty($panel['url_panel'])) {
                    $path = parse_url($f['url'], PHP_URL_PATH);
                    $q = parse_url($f['url'], PHP_URL_QUERY);
                    $internal = rtrim($panel['url_panel'], '/') . ($path ?: '') . ($q ? ('?' . $q) : '');
                    $ch = curl_init($internal);
                    curl_setopt_array($ch, [
                        CURLOPT_RETURNTRANSFER => true,
                        CURLOPT_TIMEOUT => 25,
                        CURLOPT_SSL_VERIFYPEER => false,
                        CURLOPT_FOLLOWLOCATION => true,
                        CURLOPT_HTTPHEADER => ['X-API-KEY: ' . ($panel['password_panel'] ?? '')],
                    ]);
                    $bin = curl_exec($ch);
                    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
                    curl_close($ch);
                }
            }
            if ($code >= 200 && $code < 300 && is_string($bin) && strlen($bin) > 30) {
                $content = $bin;
            }
        }
        if ($content === null || $content === '') {
            continue;
        }
        $fname = $f['name'] ?? ("config_{$fi}.txt");
        if (($f['type'] ?? '') === 'wg' && preg_match('/Endpoint\s*=\s*[^:\s]+:(\d+)/i', $content, $em)) {
            $fname = $username . '_wg_' . $em[1] . '.conf';
            $caption = 'WireGuard :' . $em[1];
        } else {
            $caption = (($f['type'] ?? '') === 'wg') ? "WireGuard #{$fi}" : "OpenVPN #{$fi}";
        }
        $path = rtrim($cwd, '/') . '/' . $fname;
        file_put_contents($path, $content);
        telegram('senddocument', [
            'chat_id' => $chat_id,
            'document' => new CURLFile($path, 'application/octet-stream', $fname),
            'caption' => $caption,
        ]);
        // QR فقط برای کانفیگ WG (محتوای conf)
        if (($f['type'] ?? '') === 'wg' && function_exists('createqrcode')) {
            try {
                $urlimage = rtrim($cwd, '/') . "/eylan_wgqr_{$chat_id}_{$fi}.png";
                $qr = createqrcode($content);
                file_put_contents($urlimage, $qr->getString());
                telegram('sendphoto', [
                    'chat_id' => $chat_id,
                    'photo' => new CURLFile($urlimage),
                    'caption' => "QR WireGuard #{$fi}",
                ]);
                @unlink($urlimage);
            } catch (Throwable $e) {
                error_log('eylan wg qr: ' . $e->getMessage());
            }
        }
        @unlink($path);
    }

    error_log('eylan_send_to_user done chat=' . $chat_id . ' files=' . count($delivery['files']));
    return $delivery;
}


} // guard
