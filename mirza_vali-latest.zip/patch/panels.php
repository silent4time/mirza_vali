<?php
/**
 * panels.php - Panel router for mirza_vali
 * Extended with EylanPanel support (v1.8.9)
 * Keeps compatibility with existing panel types.
 */

// Load Eylan integration
if (file_exists(__DIR__ . '/Eylan.php')) {
    require_once __DIR__ . '/Eylan.php';
}

// If ManagePanel class already exists (from full install), do not redefine
if (!class_exists('ManagePanel')) {

class ManagePanel
{
    /**
     * Create user on the selected panel
     */
    public function createUser($name_panel, $code_product, $username, $data = [])
    {
        $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
        if (!$panel) {
            return ['status' => false, 'msg' => 'Panel not found'];
        }

        $type = $panel['type'];

        // ===== EylanPanel =====
        if ($type === 'eylan') {
            $product = select("product", "*", "code_product", $code_product, "select");
            $volume_gb = 0;
            $expire_ts = 0;
            $days = 0;

            if ($product) {
                // Volume_constraint is usually in GB or MB depending on panel; assume GB for Eylan
                $volume_gb = floatval($product['Volume_constraint'] ?? 0);
                $service_time = intval($product['Service_time'] ?? 0); // days
                $days = $service_time;
                if ($service_time > 0) {
                    $expire_ts = time() + ($service_time * 86400);
                }
            }

            // Override from $data if provided
            if (isset($data['data_limit'])) $volume_gb = floatval($data['data_limit']);
            if (isset($data['expire'])) $expire_ts = intval($data['expire']);
            if (isset($data['days'])) $days = intval($data['days']);

            $extra = ['days' => $days, 'note' => $data['note'] ?? ('Created by bot @ ' . date('Y-m-d H:i'))];
            $result = eylan_create_user($name_panel, $username, $volume_gb, $expire_ts, $extra);

            if (isset($result['success']) && $result['success']) {
                // Try to get sub link
                $sub = eylan_get_sub($name_panel, $username);
                $sub_link = '';
                if (isset($sub['success']) && $sub['success'] && !empty($sub['url'])) {
                    $sub_link = $sub['url'];
                } elseif (isset($sub['subscription_url'])) {
                    $sub_link = $sub['subscription_url'];
                } elseif (isset($sub['link'])) {
                    $sub_link = $sub['link'];
                }

                return [
                    'status' => true,
                    'username' => $username,
                    'subscription_url' => $sub_link,
                    'configs' => [],
                    'raw' => $result
                ];
            }

            return [
                'status' => false,
                'msg' => $result['message'] ?? ($result['error'] ?? 'Eylan create user failed'),
                'raw' => $result
            ];
        }

        // For other panel types: if original ManagePanel methods are not present,
        // return a clear error so the bot does not silently fail.
        return [
            'status' => false,
            'msg' => "Panel type '{$type}' is not fully implemented in this lightweight panels.php. Use original panels.php for non-Eylan panels."
        ];
    }

    /**
     * Get user data
     */
    public function DataUser($name_panel, $username)
    {
        $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
        if (!$panel) {
            return ['status' => 'Unsuccess', 'msg' => 'Panel not found'];
        }

        if ($panel['type'] === 'eylan') {
            $result = eylan_get_user($name_panel, $username);

            if (isset($result['success']) && $result['success'] && isset($result['user'])) {
                $u = $result['user'];
            } elseif (isset($result['username'])) {
                $u = $result;
            } else {
                return [
                    'status' => 'Unsuccess',
                    'msg' => $result['message'] ?? 'User not found',
                    'raw' => $result
                ];
            }

            // Normalize to what the bot expects
            return [
                'status' => (isset($u['is_active']) && $u['is_active']) ? 'Active' : 'Disabled',
                'username' => $u['username'] ?? $username,
                'data_limit' => isset($u['data_limit']) ? floatval($u['data_limit']) * 1024 * 1024 * 1024 : 0, // to bytes
                'used_traffic' => ($u['download_bytes'] ?? 0) + ($u['upload_bytes'] ?? 0),
                'expire' => $u['expire'] ?? 0,
                'raw' => $u
            ];
        }

        return ['status' => 'Unsuccess', 'msg' => 'Unsupported panel type in lightweight mode'];
    }

    /**
     * Remove / disable user
     */
    public function RemoveUser($name_panel, $username)
    {
        $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
        if (!$panel) return false;

        if ($panel['type'] === 'eylan') {
            $result = eylan_delete_user($name_panel, $username);
            return (isset($result['success']) && $result['success']) || (isset($result['http_code']) && $result['http_code'] < 300);
        }

        return false;
    }

    /**
     * Change status (toggle)
     */
    public function Change_status($username, $name_panel)
    {
        $panel = select("marzban_panel", "*", "name_panel", $name_panel, "select");
        if (!$panel) return false;

        if ($panel['type'] === 'eylan') {
            $result = eylan_toggle_user($name_panel, $username);
            return (isset($result['success']) && $result['success']);
        }

        return false;
    }

    /**
     * Extend volume / time (basic implementation)
     */
    public function extend($method, $volume, $time, $username, $code_product, $code_panel)
    {
        // For Eylan we currently do not have a dedicated extend endpoint documented.
        // Returning false so the bot falls back to its own logic or shows error.
        return false;
    }

    public function extra_volume($username, $code_panel, $volume)
    {
        return false;
    }

    public function extra_time($username, $code_panel, $time)
    {
        return false;
    }
}

} // end class_exists check
?>
