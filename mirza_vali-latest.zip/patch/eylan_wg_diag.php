<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) {
    require_once __DIR__ . '/Eylan.php';
}

$namepanel = $argv[1] ?? '';
$username = $argv[2] ?? '';
if ($namepanel === '' || $username === '') {
    echo "Usage: php eylan_wg_diag.php \"panel_name\" \"username\"\n";
    exit(1);
}

$panel = eylan_get_panel($namepanel);
echo "panel_url=" . ($panel['url_panel'] ?? 'NULL') . "\n";
$user = eylan_get_user($namepanel, $username);
if (is_array($user)) {
    echo "allowed_wg_instances=" . json_encode($user['allowed_wg_instances'] ?? null, JSON_UNESCAPED_UNICODE) . "\n";
    echo "wg_instances=" . json_encode($user['wg_instances'] ?? null, JSON_UNESCAPED_UNICODE) . "\n";
}

$r1 = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
echo "wg1_files http=" . ($r1['http_code'] ?? 0) . "\n";
echo "wg1_files json=" . substr(json_encode($r1, JSON_UNESCAPED_UNICODE), 0, 1500) . "\n";

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    if (str_starts_with($item, 'RAWCFG:')) {
        $body = substr($item, 7);
        $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '?';
        echo "  [$i] RAWCFG endpoint=$ep len=" . strlen($body) . "\n";
    } else {
        echo "  [$i] URL=$item\n";
    }
}
echo "Done.\n";
