<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) {
    require_once __DIR__ . '/Eylan.php';
}

$namepanel = $argv[1] ?? '';
$username = $argv[2] ?? '';
if ($namepanel === '' || $username === '') {
    echo "Usage: php eylan_wg_diag.php \"panel_name\" \"username\"\n";
    exit(1);
}

$panel = eylan_get_panel($namepanel);
$base = rtrim($panel['url_panel'] ?? '', '/');
$user = eylan_get_user($namepanel, $username);
$token = '';
$su = '';
$sub = eylan_get_sub($namepanel, $username);
if (is_array($sub)) {
    $su = $sub['sub_url'] ?? '';
}
if (preg_match('#/sub/([^/]+)/#', $su, $m)) {
    $token = $m[1];
}
echo "base=$base token=$token sub_url=$su\n";

$paths = [];
if ($token !== '') {
    $paths = [
        "/api/v1/sub/$token/" . rawurlencode($username),
        "/api/v1/sub/$token/" . rawurlencode($username) . "/info",
        "/api/v1/sub/$token/" . rawurlencode($username) . "/configs",
        "/api/v1/public/sub/$token/" . rawurlencode($username),
        "/api/sub/$token/" . rawurlencode($username),
        "/sub/$token/" . rawurlencode($username) . "/data",
    ];
}
$paths[] = '/api/v1/users/' . rawurlencode($username) . '/wg1_files';
$paths[] = '/api/v1/users/' . rawurlencode($username) . '/wg2_files';
$paths[] = '/api/v1/users/' . rawurlencode($username) . '/configs';
$paths[] = '/api/v1/users/' . rawurlencode($username) . '/wireguard';
$paths[] = '/api/v1/users/' . rawurlencode($username) . '/wg2/config';

foreach ($paths as $path) {
    $res = eylan_request('GET', $path, $panel);
    $code = $res['http_code'] ?? 0;
    $raw = is_array($res) ? json_encode($res, JSON_UNESCAPED_UNICODE) : '';
    $hasPk = str_contains((string)$raw, 'PrivateKey');
    $has5183 = str_contains((string)$raw, '5183');
    echo "PATH $path http=$code hasPrivateKey=" . ($hasPk ? 'yes' : 'no') . " has5183=" . ($has5183 ? 'yes' : 'no') . " len=" . strlen((string)$raw) . "\n";
    if ($hasPk || $has5183 || ($code >= 200 && $code < 300 && strlen((string)$raw) > 100 && strlen((string)$raw) < 5000)) {
        echo "  preview=" . substr((string)$raw, 0, 400) . "\n";
    }
}

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    if (str_starts_with($item, 'RAWCFG:')) {
        $body = substr($item, 7);
        $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '?';
        $addr = preg_match('/Address\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '?';
        echo "  [$i] endpoint=$ep address=$addr len=" . strlen($body) . "\n";
    }
}
echo "Done.\n";
