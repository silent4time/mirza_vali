<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) require_once __DIR__ . '/Eylan.php';

$namepanel = $argv[1] ?? 'تیلان wireguard';
$username = $argv[2] ?? 'tylan_wireguard__63';
$panel = eylan_get_panel($namepanel);
$base = rtrim($panel['url_panel'], '/');
$user = eylan_get_user($namepanel, $username);
$token = '34e11b';
$sub = eylan_get_sub($namepanel, $username);
if (is_array($sub) && !empty($sub['sub_url']) && preg_match('#/sub/([^/]+)/#', $sub['sub_url'], $m)) {
    $token = $m[1];
}
echo "base=$base token=$token\n";

function show($label, $code, $body) {
    $ok = is_string($body) && strpos($body, 'PrivateKey') !== false;
    echo "$label http=$code len=" . strlen((string)$body)
        . " PK=" . ($ok ? 'yes' : 'no')
        . " 5182=" . (is_string($body) && str_contains($body, '5182') ? 'yes' : 'no')
        . " 5183=" . (is_string($body) && str_contains($body, '5183') ? 'yes' : 'no') . "\n";
    if (is_string($body) && $body !== '') {
        echo "  " . substr($body, 0, 600) . (strlen($body) > 600 ? "..." : "") . "\n";
    }
}

$path = "/get_subpage_download_data/" . rawurlencode($token) . "/" . rawurlencode($username);
$r = eylan_http_get_raw($base . $path, $panel);
show("GET $path", $r['code'] ?? 0, $r['body'] ?? '');

$r2 = eylan_http_get_raw($base . "/get_user_data/" . rawurlencode($username), $panel);
show("GET /get_user_data/$username", $r2['code'] ?? 0, $r2['body'] ?? '');

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    $b = str_starts_with($item, 'RAWCFG:') ? substr($item, 7) : $item;
    $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $b, $m) ? $m[1] : '?';
    echo "  [$i] endpoint=$ep len=" . strlen($b) . "\n";
}
echo "Done.\n";
