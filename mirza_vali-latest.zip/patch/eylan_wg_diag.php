<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) require_once __DIR__ . '/Eylan.php';

$namepanel = $argv[1] ?? 'تیلان wireguard';
$username = $argv[2] ?? 'tylan_wireguard__63';
$panel = eylan_get_panel($namepanel);
$base = rtrim($panel['url_panel'], '/');
$user = eylan_get_user($namepanel, $username);
$token = '34e11b';
$sub = eylan_get_sub($namepanel, $username);
if (is_array($sub) && !empty($sub['sub_url']) && preg_match('#/sub/([^/]+)/#', $sub['sub_url'], $m)) {
    $token = $m[1];
}
echo "base=$base token=$token\n";

function show($label, $body) {
    $ok = is_string($body) && strpos($body, 'PrivateKey') !== false;
    echo "$label len=" . strlen((string)$body)
        . " PK=" . ($ok ? 'yes' : 'no')
        . " 5182=" . (is_string($body) && str_contains($body, '5182') ? 'yes' : 'no')
        . " 5183=" . (is_string($body) && str_contains($body, '5183') ? 'yes' : 'no') . "\n";
    if ($ok || (strlen((string)$body) > 30 && strlen((string)$body) < 2000)) {
        echo "  " . substr((string)$body, 0, 400) . "\n";
    }
}

foreach ([
    "/get_user_data/$username",
    "/get_user_connections/$username",
    "/get_subpage_download_data/?token=$token&username=$username",
] as $path) {
    show("GET $path", eylan_http_get_body($base . $path, $panel));
}

$ch = curl_init($base . '/get_subpage_download_data/');
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode(['token' => $token, 'username' => $username]),
    CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'X-API-KEY: ' . ($panel['password_panel'] ?? '')],
    CURLOPT_SSL_VERIFYPEER => false,
]);
$body = curl_exec($ch);
$code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);
echo "POST download_data http=$code ";
show('', $body);

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    $b = str_starts_with($item, 'RAWCFG:') ? substr($item, 7) : $item;
    $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $b, $m) ? $m[1] : '?';
    echo "  [$i] endpoint=$ep len=" . strlen($b) . "\n";
}
echo "Done.\n";
