<?php
/**
 * تشخیص کانفیگ‌های WireGuard ایلان
 * اجرا: php eylan_wg_diag.php "نام_پنل" "username"
 */
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) {
    require_once __DIR__ . '/Eylan.php';
}

$namepanel = $argv[1] ?? '';
$username = $argv[2] ?? '';
if ($namepanel === '' || $username === '') {
    echo "Usage: php eylan_wg_diag.php \"panel_name\" \"username\"\n";
    exit(1);
}

$panel = eylan_get_panel($namepanel);
echo "panel_url=" . ($panel['url_panel'] ?? 'NULL') . "\n";
$user = eylan_get_user($namepanel, $username);
echo "user_keys=" . (is_array($user) ? implode(',', array_keys($user)) : 'not-array') . "\n";
if (is_array($user)) {
    foreach (['allowed_wg_instances', 'wg_instances', 'enable_wg1', 'wg1_ip', 'sub_url'] as $k) {
        if (isset($user[$k])) {
            echo "user.$k=" . json_encode($user[$k], JSON_UNESCAPED_UNICODE) . "\n";
        }
    }
}

$eps = ['wg1_files', 'wg2_files', 'wg1_config', 'wg2_config', 'all_wg_files', 'wg1/config', 'wg2/config'];
foreach ($eps as $ep) {
    $r = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/' . $ep, $panel);
    $code = $r['http_code'] ?? 0;
    $hasConf = !empty($r['config']) || !empty($r['_raw_config']);
    $keys = is_array($r) ? implode(',', array_keys($r)) : '';
    echo "GET /$ep => http=$code hasConf=" . ($hasConf ? 'yes' : 'no') . " keys=$keys\n";
    if ($hasConf) {
        $c = $r['config'] ?? $r['content'] ?? '';
        if (preg_match('/Endpoint\s*=\s*(\S+)/i', $c, $m)) {
            echo "  Endpoint={$m[1]}\n";
        }
        echo "  len=" . strlen($c) . "\n";
    }
    if (!empty($r['raw'])) {
        echo "  raw_preview=" . substr($r['raw'], 0, 80) . "\n";
    }
}

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    if (str_starts_with($item, 'RAWCFG:')) {
        $body = substr($item, 7);
        $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '?';
        echo "  [$i] RAWCFG len=" . strlen($body) . " endpoint=$ep\n";
    } else {
        echo "  [$i] URL=$item\n";
    }
}
echo "Done.\n";
