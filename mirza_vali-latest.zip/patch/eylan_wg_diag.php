<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) {
    require_once __DIR__ . '/Eylan.php';
}

$namepanel = $argv[1] ?? '';
$username = $argv[2] ?? '';
if ($namepanel === '' || $username === '') {
    echo "Usage: php eylan_wg_diag.php \"panel_name\" \"username\"\n";
    exit(1);
}

$panel = eylan_get_panel($namepanel);
$base = rtrim($panel['url_panel'] ?? '', '/');
$key = $panel['password_panel'] ?? '';
echo "panel_url=$base\n";

$user = eylan_get_user($namepanel, $username);
echo "allowed=" . json_encode($user['allowed_wg_instances'] ?? null) . "\n";
echo "wg_instances=" . json_encode($user['wg_instances'] ?? null, JSON_UNESCAPED_UNICODE) . "\n";

$r1 = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
$dl1 = $r1['servers'][0]['download_url'] ?? '';
echo "dl1=$dl1\n";
$token = '';
if (preg_match('#/download_wg1/([a-f0-9]+)/#i', $dl1, $m)) {
    $token = $m[1];
}
echo "token=$token\n";

function probe($url, $panel, $label) {
    $body = function_exists('eylan_http_get_body') ? eylan_http_get_body($url, $panel) : '';
    // also raw curl with status
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => [
            'Accept: */*',
            'X-API-KEY: ' . ($panel['password_panel'] ?? ''),
        ],
    ]);
    $raw = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    $ctype = curl_getinfo($ch, CURLINFO_CONTENT_TYPE);
    curl_close($ch);
    $ok = is_string($raw) && (strpos($raw, '[Interface]') !== false || stripos($raw, 'PrivateKey') !== false);
    $ep = ($ok && preg_match('/Endpoint\s*=\s*(\S+)/i', $raw, $m)) ? $m[1] : '-';
    echo "PROBE $label http=$code ctype=$ctype ok=" . ($ok ? 'yes' : 'no') . " ep=$ep len=" . strlen((string)$raw) . "\n";
    if (!$ok) {
        echo "  preview=" . str_replace("\n", " ", substr((string)$raw, 0, 150)) . "\n";
    }
    return $ok ? $raw : '';
}

$candidates = [];
if ($dl1 !== '') {
    $candidates['dl1'] = $dl1;
    $candidates['dl2_same'] = str_replace('/download_wg1/', '/download_wg2/', $dl1);
}

if ($token !== '') {
    $eid = '1786062444625';
    if (!empty($user['wg_instances'][1]['servers'][0]['endpoint_id'])) {
        $eid = (string) $user['wg_instances'][1]['servers'][0]['endpoint_id'];
    }
    $candidates['wg2_main'] = "$base/download_wg2/$token/$username/main_tunnel/$eid";
    $candidates['wg2_short'] = "$base/download_wg2/$token/$username/$eid";
    $candidates['wg2_inst'] = "$base/download_wg2/$token/$username/wg2/$eid";
    $candidates['wg2_name'] = "$base/download_wg2/$token/$username/ir-silentping/$eid";
    $candidates['api_wg2'] = "$base/api/v1/users/" . rawurlencode($username) . "/wg2_files";
    $candidates['api_files'] = "$base/api/v1/users/" . rawurlencode($username) . "/files";
    $candidates['api_all'] = "$base/api/v1/users/" . rawurlencode($username) . "/all_wg_files";
    $candidates['api_cfg2'] = "$base/api/v1/users/" . rawurlencode($username) . "/config?instance=wg2";
    $candidates['api_cfg2b'] = "$base/api/v1/users/" . rawurlencode($username) . "/wireguard/wg2";
    $candidates['sub'] = "$base/sub/$token/$username";
    $candidates['sub_json'] = "$base/api/v1/sub/$token/$username";
    $candidates['sub_api'] = "$base/api/v1/users/" . rawurlencode($username) . "/sub";
}

$found = [];
foreach ($candidates as $label => $url) {
    $body = probe($url, $panel, $label);
    if ($body !== '') {
        $found[$label] = $body;
    }
}

// parse sub HTML for links
$subUrl = $token !== '' ? "$base/sub/$token/$username" : '';
if ($subUrl !== '') {
    $ch = curl_init($subUrl);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => 20,
        CURLOPT_SSL_VERIFYPEER => false,
        CURLOPT_FOLLOWLOCATION => true,
        CURLOPT_HTTPHEADER => ['X-API-KEY: ' . $key],
    ]);
    $html = curl_exec($ch);
    curl_close($ch);
    echo "sub_html_len=" . strlen((string)$html) . "\n";
    if (is_string($html) && $html !== '') {
        if (preg_match_all('#https?://[^\s"\'<>]*download_wg\d+/[^\s"\'<>]+#i', $html, $m)) {
            echo "sub_download_links:\n";
            foreach (array_unique($m[0]) as $u) {
                echo "  $u\n";
                probe($u, $panel, 'from_sub');
            }
        } else {
            echo "sub_download_links: none\n";
        }
        if (preg_match_all('#/download_wg\d+/[^"\']+#i', $html, $m)) {
            echo "sub_rel_links:\n";
            foreach (array_unique($m[0]) as $path) {
                echo "  $path\n";
                probe($base . $path, $panel, 'from_sub_rel');
            }
        }
        // JSON blobs
        if (preg_match_all('#\{[^{}]{0,200}download_wg[^{}]{0,200}\}#i', $html, $m)) {
            echo "sub_json_snippets=" . count($m[0]) . "\n";
            foreach (array_slice($m[0], 0, 5) as $s) {
                echo "  $s\n";
            }
        }
        // any 5183 mention
        if (str_contains($html, '5183')) {
            echo "sub_has_5183=yes\n";
        } else {
            echo "sub_has_5183=no\n";
        }
        if (str_contains($html, '5182')) {
            echo "sub_has_5182=yes\n";
        }
        // dump interesting script src / data
        if (preg_match_all('#data-[a-z-]+=["\'][^"\']{10,200}["\']#i', $html, $m)) {
            echo "data_attrs=" . count($m[0]) . "\n";
            foreach (array_slice($m[0], 0, 10) as $a) {
                echo "  $a\n";
            }
        }
    }
}

echo "found_confs=" . count($found) . "\n";
foreach ($found as $k => $body) {
    $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '?';
    echo "  FOUND $k endpoint=$ep\n";
}
echo "Done.\n";
