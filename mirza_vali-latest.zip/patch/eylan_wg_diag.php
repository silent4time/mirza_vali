<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) {
    require_once __DIR__ . '/Eylan.php';
}

$namepanel = $argv[1] ?? '';
$username = $argv[2] ?? '';
if ($namepanel === '' || $username === '') {
    echo "Usage: php eylan_wg_diag.php \"panel_name\" \"username\"\n";
    exit(1);
}

$panel = eylan_get_panel($namepanel);
$base = rtrim($panel['url_panel'] ?? '', '/');
echo "panel_url=$base\n";
$user = eylan_get_user($namepanel, $username);
echo "allowed=" . json_encode($user['allowed_wg_instances'] ?? null) . "\n";
echo "wg_instances=" . json_encode($user['wg_instances'] ?? null, JSON_UNESCAPED_UNICODE) . "\n";

$r1 = eylan_request('GET', '/api/v1/users/' . rawurlencode($username) . '/wg1_files', $panel);
echo "wg1_files=" . substr(json_encode($r1, JSON_UNESCAPED_UNICODE), 0, 800) . "\n";

$token = '';
$dl1 = '';
if (!empty($r1['servers'][0]['download_url'])) {
    $dl1 = $r1['servers'][0]['download_url'];
    echo "dl1=$dl1\n";
    if (preg_match('#/download_wg1/([a-f0-9]+)/#i', $dl1, $m)) {
        $token = $m[1];
    }
}
$dl2 = $dl1 !== '' ? str_replace('/download_wg1/', '/download_wg2/', $dl1) : '';
echo "dl2=$dl2\n";

foreach (['wg1' => $dl1, 'wg2' => $dl2] as $label => $url) {
    if ($url === '') {
        continue;
    }
    $body = eylan_http_get_body($url, $panel);
    $ok = (strpos($body, '[Interface]') !== false);
    $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '-';
    echo "download $label: ok=" . ($ok ? 'yes' : 'no') . " endpoint=$ep len=" . strlen($body) . "\n";
    if (!$ok) {
        echo "  preview=" . substr($body, 0, 120) . "\n";
    }
}

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    if (str_starts_with($item, 'RAWCFG:')) {
        $body = substr($item, 7);
        $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $body, $m) ? $m[1] : '?';
        echo "  [$i] RAWCFG endpoint=$ep len=" . strlen($body) . "\n";
    } else {
        echo "  [$i] $item\n";
    }
}
echo "Done.\n";
