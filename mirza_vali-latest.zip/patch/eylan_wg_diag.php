<?php
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/function.php';
if (is_file(__DIR__ . '/Eylan.php')) require_once __DIR__ . '/Eylan.php';

$namepanel = $argv[1] ?? 'تیلان wireguard';
$username = $argv[2] ?? 'tylan_wireguard__63';
$panel = eylan_get_panel($namepanel);
$base = rtrim($panel['url_panel'], '/');
$user = eylan_get_user($namepanel, $username);
$token = '34e11b';
$sub = eylan_get_sub($namepanel, $username);
if (is_array($sub) && !empty($sub['sub_url']) && preg_match('#/sub/([^/]+)/#', $sub['sub_url'], $m)) {
    $token = $m[1];
}
echo "base=$base token=$token\n";

function show($label, $code, $body) {
    $ok = is_string($body) && strpos($body, 'PrivateKey') !== false;
    echo "$label http=$code len=" . strlen((string)$body)
        . " PK=" . ($ok ? 'yes' : 'no')
        . " 5182=" . (is_string($body) && str_contains($body, '5182') ? 'yes' : 'no')
        . " 5183=" . (is_string($body) && str_contains($body, '5183') ? 'yes' : 'no') . "\n";
    if (is_string($body) && $body !== '' && strlen($body) < 3000) {
        echo "  " . substr($body, 0, 500) . "\n";
    } elseif (is_string($body) && strlen($body) >= 3000) {
        echo "  " . substr($body, 0, 400) . "...\n";
    }
}

foreach ([
    "/get_user_data/$username",
    "/get_user_connections/$username",
    "/get_subpage_download_data/?token=$token&username=$username",
] as $path) {
    $r = eylan_http_get_raw($base . $path, $panel);
    show("GET $path", $r['code'] ?? 0, $r['body'] ?? '');
}

foreach ([
    json_encode(['token' => $token, 'username' => $username]),
    http_build_query(['token' => $token, 'username' => $username]),
] as $i => $payload) {
    $ch = curl_init($base . '/get_subpage_download_data/');
    $hdrs = ['X-API-KEY: ' . ($panel['password_panel'] ?? '')];
    if ($i === 0) {
        $hdrs[] = 'Content-Type: application/json';
    } else {
        $hdrs[] = 'Content-Type: application/x-www-form-urlencoded';
    }
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 20, CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => $payload,
        CURLOPT_HTTPHEADER => $hdrs,
        CURLOPT_SSL_VERIFYPEER => false,
    ]);
    $body = curl_exec($ch);
    $code = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    show("POST#$i download_data", $code, $body);
}

// context from sub HTML around get_subpage_download_data
$html = eylan_http_get_raw($base . '/sub/' . $token . '/' . rawurlencode($username), $panel);
if (!empty($html['body'])) {
    $h = $html['body'];
    foreach (['get_user_data', 'get_subpage_download_data', 'get_user_connections'] as $name) {
        $pos = strpos($h, $name);
        if ($pos !== false) {
            echo "CTX $name: " . str_replace("\n", " ", substr($h, max(0, $pos - 120), 350)) . "\n";
        }
    }
}

$files = eylan_get_wg_all_files($namepanel, $username, is_array($user) ? $user : null);
echo "collected_count=" . count($files) . "\n";
foreach ($files as $i => $item) {
    $b = str_starts_with($item, 'RAWCFG:') ? substr($item, 7) : $item;
    $ep = preg_match('/Endpoint\s*=\s*(\S+)/i', $b, $m) ? $m[1] : '?';
    echo "  [$i] endpoint=$ep len=" . strlen($b) . "\n";
}
echo "Done.\n";
