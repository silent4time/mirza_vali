# mirza_vali — Changelog

## v2.0.2 (2026-08-28)

### Critical fix — bot not starting (HTTP 500)
- **Eylan.php**: removed duplicate function declarations:
  - `eylan_delete_user`
  - `eylan_toggle_user`
  - `eylan_reset_traffic`
- Error was: `PHP Fatal error: Cannot redeclare function eylan_delete_user()`
- Telegram + Bale webhooks returned 500 and bot did not respond
- Unique helpers kept: `eylan_revoke_user`, `eylan_list_users`, `eylan_hwid_*`

## v2.0.1
- Previous stable classic release

## v2.0.0
- Classic line continuation (install path `/home/mirza_vali`)
